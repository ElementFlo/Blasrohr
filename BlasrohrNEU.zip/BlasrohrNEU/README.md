# KKS Hochhausen: Live-Passenerkennung (Prototyp V8)

## Enthalten
- Tapo-C200C-Livestream per Media3 RTSP (Stream 1)
- Start einer Passe **ausschließlich durch Knopfdruck**
- Referenzbild beim Start und 3-Minuten-Countdown
- Bildvergleich ungefähr alle 750 ms, asynchron außerhalb des UI-Threads
- sechs unabhängige Statusanzeigen: `Wartet` oder `Erkannt`
- Stabilitätsprüfung: drei aufeinanderfolgende ähnliche Messungen
- automatischer Stopp bei sechs bestätigten Kandidaten oder nach drei Minuten
- vorzeitige manuelle Beendigung möglich
- **vor dem Speichern** Kontrollfenster mit einzeln änderbaren Werten 0, 6, 7, 8, 9, 10
- fehlende Treffer bleiben `Wartet`, bis der Benutzer sie ausdrücklich bewertet
- erst die geprüfte Passe wird in SQLite gespeichert; 5/10-Passen-Training und Archiv bleiben erhalten
- KKS-Wappen und fünf Tabs

## Wichtige Einschränkung
Dies ist ein funktionsorientierter **Prototyp**, keine nachgewiesen präzise automatische Schießwertung. Die Liveüberwachung nutzt die vorhandene V7-Metallschafterkennung. Deren Trefferpositionen sind anhand der bisherigen Bilder noch nicht ausreichend validiert. Eine hohe angezeigte Konfidenz ist keine Garantie für eine korrekte Punktzahl. Vor dem Speichern müssen die sechs Vorschläge kontrolliert werden.

Der aktuelle Media3-Framezugriff nutzt `TextureView.getBitmap`. Deshalb muss die Kamera-Vorschau auf dem Tablet sichtbar/aktiv sein, wenn eine Passe gestartet und überwacht wird. Bei einem unsichtbaren Kamera-Tab können Frames fehlen. Für produktiven Einsatz wäre eine vom UI unabhängige Decoder-Framepipeline erforderlich.

## Build
Gradle 8.13, AGP 8.13.2, compileSdk 35, Media3 1.8.1, JDK 21. Bitte Projekt außerhalb von OneDrive entpacken. Vollständiger Android-Build und Gerätetest konnten hier nicht ausgeführt werden.

## Wertungskorrektur V9
- Sechs getrennte, gut lesbare Karten statt einer langen Spinner-Liste.
- Farbmarkierung nach automatisch gemeldeter Sicherheit: Rot bei nicht erkannt oder <55%, Gelb bei 55-79%, Grün erst nach manueller Bestätigung.
- Für jede Scheibe sechs große Wertungstasten: 0, 6, 7, 8, 9, 10.
- Ursprünglicher Automatikwert, angezeigte Konfidenz und aktueller Endwert stehen nebeneinander.
- Gesamtpunktzahl, geprüfte Scheiben und Korrekturzähler aktualisieren sich sofort.
- Alle sechs Scheiben müssen ausdrücklich bestätigt sein, bevor die geprüfte Passe gespeichert wird.
- Die Prozentzahl ist ein interner Algorithmuswert und keine validierte Trefferwahrscheinlichkeit.

## Einstichpunkt-Prototyp V10
Neue `EntryPointEstimator.kt`: Die beiden Enden eines neu erkannten Metallschafts werden anhand eines neu erschienenen, gesättigten Kunststoffkopfs beliebiger Farbe unterschieden. Der Endpunkt gegenüber dem Kopf wird als Einstichpunkt vorgeschlagen. Bei nicht eindeutig zuzuordnendem Kopf wird kein Treffer erfunden und die Scheibe bleibt `Wartet`. Das magentafarbene Overlay zeigt den geschätzten Punkt. Die bestehende manuelle Korrektur V9 bleibt zwingend. Dies ist eine heuristische Näherung, keine validierte Konturverfolgung und keine garantierte Ringwertung.

## V11: Live-Dashboard nach Designvorlage
- Dunkelgrüner Vereinskopf mit vorhandenem KKS-Wappen; Navigation unten.
- Im Durchlauf-Tab: Teilnehmer, großer 03:00-Timer, manuell startbare Passe, sechs Kacheln in 2 Spalten (3 bei breiten Displays), laufende Punktesumme.
- Jede Kachel zeigt einen **echten Ausschnitt** des Tapo-Kamerabildes, nicht die Beispielgrafik. Bildausschnitte werden aus der gespeicherten Sechs-Scheiben-Kalibrierung berechnet und während der Passe aktualisiert.
- Pro Kachel: Wartet/Erkannt/Unsicher, automatischer Wertungsvorschlag und interner Konfidenzwert.
- Media3-PlayerView wird beim Wechsel zwischen Kamera- und Durchlauf-Tab umgehängt, damit der TextureView im aktiven Durchlauf weiterhin Videoframes liefern kann. Ein kleines Original-Livebild bleibt über den sechs Kacheln sichtbar.
- Die bisherige automatische Erkennung V10, Timer, manuelle Korrektur V9 und SQLite-Archiv bleiben erhalten.

**Prototyp-Einschränkung:** Die tatsächliche Erkennungsgenauigkeit ist noch nicht validiert; Wertungen müssen weiterhin vor dem Speichern bestätigt werden. Das Umhängen des PlayerView kann auf einzelnen Geräten einen kurzen Surface-Neustart verursachen. Vollständiger Android-Build/Gerätetest hier nicht möglich.


V13: Überarbeitetes 3x2-Dashboard, vergrößertes Vereinswappen, Informationskarten, Gold-/Rot-Aktionen, Status- und Detailbuttons, dunkelgrüne Navigation. Die Treffererkennung bleibt unverändert und ist weiterhin experimentell. Kein Android-Gerätetest durchgeführt.


## V15: Querformat und Android-Systemnavigation
- Feste Hochformat-Sperre aus AndroidManifest entfernt.
- Rotation während laufender Passe wird über onConfigurationChanged behandelt, damit der Timer/RTSP-Player nicht durch Activity-Neustart verloren gehen.
- Dynamische Insets für Status-, Navigations- und Aussparungsbereiche, damit die untere App-Navigation nicht hinter Androids Tablet-Taskbar liegt.
- Querformat: kompakter Vereinskopf (72dp), kompakte untere Navigation (58dp), kleinere Livebilder (112dp), weiterhin 3x2 Scheiben.
- Hochformat: bisherige Kartengrößen und Design bleiben erhalten.
- Geräte- und Buildtest erforderlich.

## V16: Konservative Einstichpunktanalyse
- Vorhandene PCA-Schafterkennung mit farbunabhängiger Kopfzuordnung bleibt Ausgangspunkt.
- Geschätzte Eintrittsstelle wird an reale zusammenhängende Änderungs-Pixel des Schafts zurückgebunden, statt den theoretischen PCA-Endpunkt ungeprüft zu verwenden.
- Treffer in unmittelbarer Nähe einer Wertungsringgrenze erhalten eine niedrigere algorithmische Sicherheit.
- Zeitliche Stabilisierung über mindestens 5 konsistente Frames (statt 3), tolerierter Ortsabstand relativ zur kalibrierten Scheibengröße, Medianposition und Mehrheitswert.
- Bestätigte Treffer werden im Scheibenausschnitt mit einem Fadenkreuz markiert.
- Unsichere Kandidaten bleiben kontrollpflichtig. Dies ist eine experimentelle Verbesserung, keine nachgewiesene Genauigkeitssteigerung.
- Keine neuen externen Android-Abhängigkeiten.


## V19: Kopf-zu-Schaft-Suche (experimentell)
- Kopfkandidaten werden ausschließlich als neu hinzugekommene, gesättigte Farbpixel gegenüber dem Referenzbild ermittelt.
- Eine lokale Graphsuche beginnt unmittelbar neben dem Kopf und verfolgt nur neu hinzugekommene, schmale, dunkle oder metallisch-neutrale Pixel.
- Kein globales Auswählen einer beliebigen langen Linie mehr.
- Plausibilitätsfilter: Mindestlänge, Verhältnis Pfadlänge zu Abstand, Anzahl Schaftpixel und Position innerhalb der Scheibe.
- Mehrere mögliche Ergebnisse werden verworfen; die manuelle Korrektur bleibt erforderlich.
- Die bisherigen Layouts aus V18 und die Fünf-Frame-Bestätigung bleiben erhalten.
- Die Genauigkeit ist nicht validiert. Die neue Methode kann bei unterbrochenem Schaft oder schwachem Kontrast Treffer auslassen.


## V20: Zweistufige Live-Erkennung (Prototyp)
1. `ArrowPresenceDetector`: Vergleich des ausgerichteten Referenzbilds mit dem Livebild je Scheibe. Lokal begrenzte Änderungen müssen in mindestens drei Bildern auftreten. Der Status `Pfeil · prüfen` bedeutet ausschließlich, dass eine dauerhafte Bildänderung erkannt wurde.
2. `HeadToShaftDetector`: Nur eine ausreichend eindeutige Schaftkontur mit plausibler Einstichposition kann nach fünf stabilen Messungen eine automatische Wertung liefern.
3. Die beiden Zustände sind unabhängig. `Pfeil · prüfen` zählt nicht zur Gesamtpunktzahl; manuelle Kontrolle bleibt erforderlich.
4. Breite Lichtwechsel und kurzzeitige Störungen werden heuristisch ausgefiltert. Die Schwellen sind nicht mit annotierten Tapo-Aufnahmen kalibriert.

Kein vollständiger Android-Build oder Tablet-Test durchgeführt.


## V21: Lueckenueberbrueckung und Details-Diagnose
- Anwesenheitsstatus wird innerhalb einer Passe nach drei positiven Frames gespeichert und nicht mehr zurueckgesetzt. Neue Passe startet mit neuen Slots.
- Kopf-zu-Schaft-Graph kann kleine Pixelunterbrechungen ueberbruecken (maximal zwei Bruecken pro Pfad; Richtungspruefung gegen Rueckspruenge).
- DETAILS zeigt Live-Diagnosewerte: Pfeilstatus, Aenderungspixel, Kopf-Kandidaten, Schaft-Maskenpixel, Grund bei Ablehnung, stabile Messungen, Einstichkoordinaten, Punktzahl und Sicherheit.
- Schaftpixel sind Kandidaten der Maske und kein Beweis einer korrekt verfolgten Schaftkontur.
- Experimenteller Prototyp, nicht am Android-Geraet gebaut oder validiert.


## V22: Engere Kopf- und Schaftfilterung
- Neue Farbkomponenten werden nach Groesse, Kompaktheit und Ausdehnung gefiltert.
- Schaftmaske erfordert staerkeren Referenzbildunterschied und metallische bzw. dunkle Pixel.
- Kopfnahe Schaftsuche mit begrenzter Lueckenueberbrueckung, Richtungspruefung und Pfadqualitaet.
- Mehrere raeumlich abweichende, aehnlich plausible Endpunkte fuehren zu keiner automatischen Wertung.
- DETAILS zeigt gefilterte Kopfanzahl, beste Konturlaenge, ueberbrueckte Luecken und plausible Endpunkte.
- Dauerhafter Pfeilstatus aus V21 und Design aus V18 bleiben erhalten.
- Prototyp ohne vollstaendigen Android-Build und ohne validierte Trefferquote.


## V23: Kandidatengruppierung und 3 Messungen
- Nicht aufeinanderfolgende plausible Einstichpunktmessungen werden ueber bis zu 24 Kandidaten gesammelt.
- Raeumlich nahe Punkte bilden Cluster mit scheibengroessenabhaengiger Toleranz.
- 3 Messungen im besten Cluster, davon mindestens 2 gleiche Wertungen, koennen einen Treffer bestaetigen.
- Ein gleich starkes alternatives Cluster verhindert eine automatische Bestaetigung.
- Die sichtbare Schaftlaenge ist kein fester Wertungsschwellwert; die Konturqualitaet gewichtet Geradlinigkeit staerker.
- Details-Popup zeigt Clusteranzahl und Bestaetigung /3. Dauerstatus und Design bleiben erhalten.
- Experimentell, kein Android-Build oder Geraetetest durchgefuehrt.


## V24: Lokale Schaftende-Projektion
- Die letzten Schaftpixel des verfolgten Pfads bestimmen eine lokale Tangente.
- Die Projektion wird auf 1,5 bis 4 Bildpixel begrenzt und muss vom Kopf wegzeigen.
- Unplausible lokale Linienverlaeufe werden abgelehnt, statt einen Einstichpunkt zu erfinden.
- DETAILS zeigt Projektionsdistanz und lokalen Linienfehler.
- Drei-Messungen-Cluster, dauerhafter Pfeilstatus und Design bleiben erhalten.
- Die Methode ist experimentell und nicht an manuell markierten Einstichpunkten validiert.


## V25: Schaftpfad-Overlay in DETAILS
- Der Detektor liefert den tatsaechlich ausgewaehlten Pixelpfad mit Kopf- und Alternativkoordinaten.
- DETAILS zeigt einen aktuellen ausgerichteten Scheibenausschnitt mit blauem Pfad, gruenem Kopf, roter Wertungsmarkierung und gelben alternativen Punkten.
- Auch bei konkurrierenden Kandidaten wird der beste Diagnosepfad angezeigt, ohne automatisch eine Wertung zu erzwingen.
- Die 3-Messungen-Cluster und das Layout bleiben erhalten.
- Die Overlaydaten stammen aus der letzten Analyse, das Hintergrundbild ist ein neuer Snapshot. Bei Bewegung koennen leichte Abweichungen entstehen.
- Noch kein vollstaendiger Android-Build und keine Validierung auf dem Tablet.


## V26: Kopf-Schaft-Zuordnung (Gruen/Pink-Testmodus)
- Farbkopferkennung auf neue gruen- und pinkfarbene Flaechen eingeschraenkt (HSV, Farbsaettigung und Referenzbild-Differenz).
- Kopf-Kandidaten werden nach Kompaktheit, Groesse und Farbveraenderung priorisiert.
- Eine Schaftverbindung muss unmittelbar neben dem Kopf in einem engen Winkelsektor beginnen.
- Startpunkte aus anderen Richtungen werden verworfen, um zufaellige Ringkonturen weniger haeufig zu verfolgen.
- Schaftpfad-Overlay, alternative Kandidaten, 3-Messungen-Cluster und bestehendes Design bleiben erhalten.
- Unsichere Treffer werden weiterhin nicht automatisch gewertet.
- Experimenteller Testmodus: Pink/Grün; keine Garantie fuer exakte HSV-Abdeckung aller Beleuchtungen.
- Noch kein Android-Build oder Tablet-Test.


## V27: Tolerante Schaftsuche
- Gruen/Pink-Farberkennung mit groesserer Helligkeits- und Saettigungstoleranz.
- Schaftsuche startet in mehreren Richtungen unmittelbar am Kopf statt ausschliesslich im staerksten Winkelsektor.
- Bis zu drei kurze Pixelunterbrechungen werden unter Richtungspruefung ueberbrueckt.
- Mindestlaenge und Geradlinigkeit etwas toleranter; alternative Pfade werden weiterhin gegeneinander geprueft.
- 3-Messungen-Cluster, dauerhafter Pfeilstatus, Schaftpfad-Overlay und Design bleiben erhalten.
- Experimentell: mehr Sensitivitaet kann auch falsche Schaftkandidaten erzeugen. Kein Android-Build/Geraetetest.


## V28: Linienbasierte Erkennung (experimentell)
- Die Pixelgraph-Schafterkennung wurde in der Live-Auswertung durch Kopf-verankerte Strahlensuche ersetzt.
- Pro Kopf werden Richtungen in 5-Grad-Schritten auf schmale, geaenderte Schaftpixel untersucht; kurze fehlende Abschnitte sind erlaubt.
- Schaftende ist der letzte plausible Linienpixel, nicht eine vorgegebene Schaftlaenge.
- Mehrdeutige, raeumlich getrennte Linien werden nicht automatisch gewertet.
- DETAILS zeigt die gefundenen Linienpixel als blaues Overlay und Alternativen gelb.
- Drei-Messungen-Bestaetigung, Dauerstatus und Layout bleiben erhalten.
- Kein vollstaendiger Android-Build oder Genauigkeitstest auf echten Aufnahmen.


## V29: Geometrisch gekoppelte Wertung
- Schaftachsen muessen mindestens drei geaenderte Linienpunkte direkt am farbigen Kopf aufweisen.
- Die Live-Kandidaten werden an den aktuell erkannten Kopf gebunden. Wechselt der Kopf deutlich, werden alte Messungen verworfen.
- Bereits bestaetigte Punkte werden bei widersprechender aktueller Geometrie zurueckgesetzt.
- Die 3-Messungen-Regel bestaetigt nur, wenn der aktuelle Linienendpunkt nahe am Clusterpunkt liegt.
- DETAILS-Overlay, manuelle Korrektur, Design und dauerhafter Pfeilanwesenheitsstatus bleiben erhalten.
- Experimentell: ohne Android-Build und ohne Test mit manuell annotierten Einstichpunkten.


## V30 experimentell: Segmentzusammenfuehrung
- Statt zusammenhaengender Pixelpfade werden kurze Linienlaeufe entlang kopfverankerter Suchachsen ermittelt.
- Kollineare Segmente werden bei maximal 6 Pixeln Unterbrechung zusammengefuehrt.
- Der Anfang muss innerhalb von 7 Pixeln des Kopfanschlusses liegen.
- Qualitaet beruecksichtigt Linienstuetzung, Laenge und ueberbrueckte Luecken.
- Mehrdeutige Endpunkte werden nicht automatisch gewertet.
- Overlay und 3-Messungen-Regel aus V29 bleiben bestehen.
- Keine nachgewiesene Treffergenauigkeit und kein Android-Geraetebuild.


## V30.1: Kopf-Schaft gemeinsam bewerten
- Kopf-Suchradius bis 1.38 Scheibenradien; erfasst auch Koepfe ausserhalb des Scheibenrandes.
- Gruen/Pink mit toleranteren HSV-Grenzen und Referenzbild-Farbdifferenz.
- Kleine/dunkle Kopfkomponenten ab zwei Pixeln; bis 35 Kandidaten werden auf einen angeschlossenen Schaft untersucht.
- Gemeinsame Hypothesenqualitaet aus Kopfkompaktheit, Kopfgrösse, direktem Schaftanschluss, geradliniger Linienunterstuetzung und Luecken.
- Keine automatische Wertung bei konkurrierenden gleichwertigen Einstichpunkten.
- Drei-Messungen-Regel und grafisches Overlay unveraendert.
- Experimentell: kein vollstaendiger Android-Build oder nachgewiesener Offline-Genauigkeitsgewinn.


## V30.2: Kandidatenreduktion (experimentell)
- Kopfkomponenten mit weniger als 4 Pixeln und stark laengliche Komponenten ausgeschlossen.
- Ein Kopf wird nur mit einem Schaftlauf direkt am Kopf akzeptiert (Anfangsabstand <= 5 Pixel, mindestens 3 gestuetzte Pixel).
- Schaftachse braucht mindestens 9 Linienpixel und hoehere Dichte.
- Gemeinsam bewertete Kopf-Schaft-Paare bevorzugen dichte, lange Linien mit kleinen Luecken.
- Alternative raeumlich getrennte Punkte werden bereits ab 85 Prozent der Bestqualitaet als Mehrdeutigkeit gemeldet.
- Jede Live-Scheibe wird weiterhin ueber ihren eigenen kalibrierten Ausschnitt analysiert.
- Kein Android-Build oder Nachweis, dass alle sechs Pfeile in Serie C korrekt erkannt werden.


## V30.3: Schaft zuerst
- Neues schaftbasiertes Suchverfahren: metallische Bildveraenderungen bilden Linienhypothesen, nicht Kopf-Farbkomponenten.
- Unterbrochene Schaftpixel werden mit einer schmalen Linienband-Abtastung beruecksichtigt.
- Kopfzuordnung erst nach Linienfindung: ein Linienende muss nahe einem neuen gruenen/pinken Kopf liegen.
- Gegenueberliegendes Ende wird als vermuteter Einstichpunkt gewertet, sofern es innerhalb der Scheibe liegt.
- Gleichwertige, raeumlich verschiedene Endpunkte erzeugen keine automatische Wertung.
- Alte kopfbasierte Suche bleibt als Fallback; DETAILS-Overlay und Drei-Messungen-Regel bleiben erhalten.
- Die roten handgezeichneten Markierungen sind Referenzdaten, kein Merkmal des Live-Algorithmus.
- Experimentell, Android-Build und quantitative Genauigkeitsvalidierung ausstehend.


## V30.4: Geometrische Schaftauswahl (Prototyp)
- Gruen/pinke Kopfkandidaten bleiben nach Groesse und Form gefiltert.
- Eine Metalllinie ist nur gueltig, wenn ein Endpunkt mit einem neuen Kopf verbunden ist.
- Nahezu identische Linien mit gleichem Kopf, Winkel und Endpunkt werden gruppiert.
- Nahe gedruckter Ringgrenzen werden tangentiale Linien abgewertet oder ausgeschlossen.
- Mehrere raeumlich unterschiedliche, aehnlich plausible Einstichpunkte ergeben keine automatische Wertung.
- Bestehende 3-Messungen-Regel und DETAILS-Overlay bleiben erhalten.
- Experimentell; weder Android-Build noch Genauigkeitsnachweis gegen Serie C abgeschlossen.


## V30.5 experimental endpoint and attachment refinement
- Shaft-first search now requires at least 3 changed metallic pixels in the first 12 pixels near the coloured head.
- Attached shaft evidence receives extra ranking weight.
- Ambiguity cutoff tightened to 82 percent of best score, preventing more uncertain automatic scores.
- This is not a verified six-of-six recognition result. The reference comparison remains an offline OpenCV approximation.


## V31 experimental offline evaluation
- Median illumination-drift correction from sparse reference samples.
- Head pixels excluded from metallic shaft evidence.
- Long breaks in shaft traces rejected instead of joining unrelated ring segments.
- Shaft/head attachment and conservative ambiguity checks retained.
- Three-measurement confirmation remains unchanged.
- Not a verified 6/6 detector; Android build and device test pending.


## V31.1 geometric reconstruction (experimental)
- Fit a robust total-least-squares shaft axis to observed changed metallic pixels.
- Iteratively reject off-axis pixels (2.3 px) to suppress rings and noise.
- Determine two observed projection endpoints, associate the nearest with the coloured head and use the opposite as tentative entry point.
- Require a plausible head connection and entry point inside the calibrated target.
- Retain conservative ambiguity and temporal confirmation checks.
- This is source-level implementation; Kotlin/Android runtime and 6/6 accuracy have not been verified.


## V31.2 Metal-first connected geometry (experimental)
- Isolates new metallic change pixels and groups eight-connected components.
- Fits a principal axis and rejects short or thick components.
- Requires a green/pink head close to one observed component endpoint.
- Uses the opposite observed endpoint as insertion candidate.
- Falls back to the previous shaft ray search only if no metal-head pair exists.
- Existing ambiguity handling and multi-frame confirmation retained.
- Android build and six-of-six accuracy not yet demonstrated.
