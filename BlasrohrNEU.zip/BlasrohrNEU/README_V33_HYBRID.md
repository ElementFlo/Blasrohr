# V33 Hybrid-Erkennung (experimentelles Android-Quellprojekt)

1. Bestehende Schaftkandidaten und Achsenrekonstruktion aus V32 als Standard.
2. Separate Pruefung der beiden Schaftseiten anhand neuer Metallpixel.
3. Verlaengerung nur bei zusammenhaengender Metallinformation, zwei Seiten und richtungskonsistenter Fortsetzung.
4. Lokale Endpunktkorrektur nur bei Konflikt und Uebereinstimmung mit der Zweikantenpruefung.
5. Bei unsicheren oder widerspruechlichen Signalen bleibt der urspruengliche Endpunkt erhalten. Bestehende Mehrdeutigkeitspruefung bleibt aktiv.

Status: Quellcode-Prototyp. Keine Kotlin-Kompilierung, keine Android-APK, kein direkter Serie-C-Test der Kotlin-Implementierung. Python-Offline-Ergebnisse einzelner Komponenten lassen sich nicht als V33-Gesamtergebnis ausgeben.
