# V32.4 experimental source
V32.3-inspired baseline retained. Extended shaft tracking accepted only with dense contiguous new-metal support and direction consistency; otherwise original endpoint retained.
Serie C offline: V32.3 4/6 endpoints within 5px. Ungated variant A improves target 4 to 1.8px but degrades target 1, so it is not enabled unconditionally.
Target 2: a further local metal-to-paper transition approach was considered but not integrated because no improvement has been demonstrated. The existing 15.2px error remains unresolved.
This Kotlin project is not a compiled APK. No direct Kotlin Serie C execution has been performed.
