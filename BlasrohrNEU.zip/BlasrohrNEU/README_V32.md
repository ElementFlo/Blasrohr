# KKS Hochhausen V32 Android source prototype

V32.3-inspired shaft selection with conservative evidence-gated extended endpoint tracking.
The prior app structure, camera workflows and ambiguity checks are retained.
Extension requires at least six strong additional samples, a run of four, at least 60 percent support, and evidence immediately after the previous tip.

**Important:** This Kotlin implementation is not the Python/OpenCV detector, and is not validated against Serie C. No Android APK was built in this environment.

Build in Android Studio: open BlasrohrV3, sync Gradle, select debug, Build APK(s). The Gradle wrapper JAR is absent in this source snapshot; Android Studio must supply a configured Gradle installation.

Offline research results: V32.3 baseline 4/6 under 5 px, ungated long trace variant A 4/6 but degraded target 1; this new gated implementation has not been directly tested on Android.
