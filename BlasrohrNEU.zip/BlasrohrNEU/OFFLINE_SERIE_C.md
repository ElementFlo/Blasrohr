# Serie C offline: independent OpenCV baseline

Inputs: leer.jpeg and orginal.jpeg for detection; markiert.jpeg only for reference comparison.

The Kotlin V31 detector was NOT executed in Android. This is a separate OpenCV proxy, not a measured V31 gain.

| Target | Red reference extracted | Angle error (deg) | Endpoint error (px) |
|---|---|---:|---:|
| 1 | yes | 13.6 | 13.8 |
| 2 | yes | 12.5 | 23.1 |
| 3 | no | n/a | n/a |
| 4 | yes | 2.5 | 10.3 |
| 5 | yes | 3.7 | 2.5 |
| 6 | no | n/a | n/a |

Four red reference lines were extracted; targets 3 and 6 had no isolated red stroke in the provided marked-vs-original difference.
The six shafts and the known total of 43 points are NOT automatically verified.
No three-frame temporal test is possible with only one scored frame.
Full Android build and runtime accuracy testing remain outstanding.
