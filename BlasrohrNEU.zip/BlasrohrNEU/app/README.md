

### V17: Experimentelle Konturverfolgung
Die Kandidatenmaske wird als Pixelgraph verfolgt. Zwei Breitensuchen liefern eine lange zusammenhängende Kontur, auch bei mäßigen Biegungen. Zu breite oder stark verzweigte Konturen werden abgelehnt. Die Kopfzuordnung bleibt konservativ; uneindeutige Ergebnisse bleiben Wartet. Die Genauigkeit ist noch nicht mit Referenz-Einstichpunkten validiert.
