plugins { id("com.android.application");id("org.jetbrains.kotlin.android") }
android { namespace="de.florian.blinksnapshot";compileSdk=35
 defaultConfig{applicationId="de.florian.blinksnapshot";minSdk=26;targetSdk=35;versionCode=7;versionName="0.7.0"}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17} }
kotlin{jvmToolchain(17)}
dependencies{
 implementation("androidx.appcompat:appcompat:1.7.1")
 implementation("com.google.android.material:material:1.13.0")
 implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
 implementation("androidx.media3:media3-exoplayer:1.8.1")
 implementation("androidx.media3:media3-exoplayer-rtsp:1.8.1")
 implementation("androidx.media3:media3-ui:1.8.1")
}
