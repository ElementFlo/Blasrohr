package de.florian.blinksnapshot

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class TargetCal(
    val cx: Float,
    val cy: Float,
    val rx: Float,
    val ry: Float,
    val rings: List<Float>,
    val imageWidth: Int,
    val imageHeight: Int
)

data class Hit(
    val no: Int,
    var score: Int,
    val auto: Int,
    val x: Float?,
    val y: Float?,
    val confidence: Float
)

data class AlignmentResult(val bitmap: Bitmap, val offsetX: Int, val offsetY: Int, val error: Double)

object Vision {
    fun align(start: Bitmap, end: Bitmap): AlignmentResult {
        require(start.width > 0 && start.height > 0 && end.width > 0 && end.height > 0)
        val width = min(start.width, end.width)
        val height = min(start.height, end.height)
        val sampleWidth = min(320, width)
        val sampleHeight = (height * sampleWidth.toFloat() / width).toInt().coerceAtLeast(120)
        val a = Bitmap.createScaledBitmap(start, sampleWidth, sampleHeight, true)
        val b = Bitmap.createScaledBitmap(end, sampleWidth, sampleHeight, true)
        val ap = IntArray(sampleWidth * sampleHeight)
        val bp = IntArray(sampleWidth * sampleHeight)
        a.getPixels(ap, 0, sampleWidth, 0, 0, sampleWidth, sampleHeight)
        b.getPixels(bp, 0, sampleWidth, 0, 0, sampleWidth, sampleHeight)
        if (a !== start) a.recycle()
        if (b !== end) b.recycle()

        var bestError = Double.MAX_VALUE
        var bestDx = 0
        var bestDy = 0
        val maxShift = 8
        for (dy in -maxShift..maxShift) {
            for (dx in -maxShift..maxShift) {
                var error = 0L
                var count = 0
                var y = 12
                while (y < sampleHeight - 12) {
                    val yy = y + dy
                    if (yy in 0 until sampleHeight) {
                        var x = 12
                        while (x < sampleWidth - 12) {
                            val xx = x + dx
                            if (xx in 0 until sampleWidth) {
                                error += abs(luma(ap[y * sampleWidth + x]) - luma(bp[yy * sampleWidth + xx]))
                                count++
                            }
                            x += 3
                        }
                    }
                    y += 3
                }
                if (count > 0) {
                    val average = error.toDouble() / count
                    if (average < bestError) {
                        bestError = average
                        bestDx = dx
                        bestDy = dy
                    }
                }
            }
        }

        val scaleX = width.toFloat() / sampleWidth
        val scaleY = height.toFloat() / sampleHeight
        val offsetX = (bestDx * scaleX).toInt()
        val offsetY = (bestDy * scaleY).toInt()
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        Canvas(output).drawBitmap(end, -offsetX.toFloat(), -offsetY.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
        return AlignmentResult(output, offsetX, offsetY, bestError)
    }

    fun calibrate(image: Bitmap): List<TargetCal> {
        val candidates = yellowComponents(image)
            .sortedBy { it.second }
            .chunked(2)
            .flatMap { row -> row.sortedBy { it.first } }
            .take(6)
        if (candidates.size != 6) return emptyList()
        val rows = candidates.chunked(2)
        if (rows.size != 3 || rows.any { it.size != 2 }) return emptyList()
        val rowCenters = rows.map { row -> row.map { it.second }.average() }
        if (!(rowCenters[0] < rowCenters[1] && rowCenters[1] < rowCenters[2])) return emptyList()
        val raw = candidates.map { (x, y, yellowRadius) ->
            // The segmented yellow component is the COMPLETE yellow disc
            // (10 + 9), whose outer boundary is 40% of the target radius.
            // The previous /0.20 doubled every target and allowed other
            // targets, clips and wall details into the dart search area.
            val outer = yellowRadius / 0.40f
            TargetCal(
                x,
                y,
                outer,
                outer,
                listOf(0.20f, 0.40f, 0.60f, 0.80f),
                image.width,
                image.height
            )
        }
        val medianRadius = raw.map { it.rx }.sorted()[raw.size / 2]
        return raw.filter { target ->
            target.rx in (medianRadius * 0.72f)..(medianRadius * 1.28f)
        }.takeIf { it.size == 6 } ?: emptyList()
    }

    fun evaluate(start: Bitmap, alignedEnd: Bitmap, stored: List<TargetCal>): MutableList<Hit> {
        val calibrations = stored.map { scaleCalibration(it, start.width, start.height) }
        return calibrations.mapIndexed { index, target ->
            val point = needle(start, alignedEnd, target)
            val normalized = point?.let { hypot((it.first - target.cx) / target.rx, (it.second - target.cy) / target.ry) }
            val score = if (normalized == null) 0 else when {
                normalized <= target.rings[0] -> 10
                normalized <= target.rings[1] -> 9
                normalized <= target.rings[2] -> 8
                normalized <= target.rings[3] -> 7
                normalized <= 1.04f -> 6
                else -> 0
            }
            val boundaryDistance = if (normalized == null) 0f else listOf(0.20f, 0.40f, 0.60f, 0.80f, 1.0f).minOf { abs(normalized - it) }
            val confidence = if (point == null) 0f else (point.third * if (boundaryDistance < 0.035f) 0.65f else 1f).coerceAtMost(0.79f)
            Hit(index + 1, score, score, point?.first, point?.second, confidence)
        }.toMutableList()
    }


    fun renderOverlay(image: Bitmap, stored: List<TargetCal>, hits: List<Hit>): Bitmap {
        val output = image.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val targets = stored.map { scaleCalibration(it, output.width, output.height) }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.MAGENTA }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; textSize = 34f; color = Color.WHITE; setShadowLayer(5f, 0f, 0f, Color.BLACK) }
        targets.forEachIndexed { index, target ->
            canvas.drawOval(target.cx-target.rx, target.cy-target.ry, target.cx+target.rx, target.cy+target.ry, paint)
            val hit = hits.getOrNull(index)
            if (hit?.x != null && hit.y != null) {
                canvas.drawCircle(hit.x, hit.y, 14f, paint)
                canvas.drawLine(hit.x-22f, hit.y, hit.x+22f, hit.y, paint)
                canvas.drawLine(hit.x, hit.y-22f, hit.x, hit.y+22f, paint)
            }
            canvas.drawText("${index+1}: ${hit?.score ?: 0}", target.cx-target.rx, target.cy-target.ry-8f, text)
        }
        return output
    }

    private fun scaleCalibration(target: TargetCal, width: Int, height: Int): TargetCal {
        if (target.imageWidth <= 0 || target.imageHeight <= 0 || (target.imageWidth == width && target.imageHeight == height)) return target
        val sx = width.toFloat() / target.imageWidth
        val sy = height.toFloat() / target.imageHeight
        return target.copy(cx = target.cx * sx, cy = target.cy * sy, rx = target.rx * sx, ry = target.ry * sy, imageWidth = width, imageHeight = height)
    }

    private fun measureRings(image: Bitmap, cx: Float, cy: Float, radius: Float): List<Float> {
        val profile = DoubleArray(100)
        for (position in 5..95) {
            var total = 0.0
            var count = 0
            for (angle in 0 until 360 step 10) {
                val radians = Math.toRadians(angle.toDouble())
                val x = (cx + cos(radians) * radius * position / 100).toInt()
                val y = (cy + sin(radians) * radius * position / 100).toInt()
                if (x in 0 until image.width && y in 0 until image.height) {
                    total += luma(image.getPixel(x, y))
                    count++
                }
            }
            profile[position] = if (count > 0) total / count else 255.0
        }
        val lows = (8..92).sortedBy { profile[it] }.fold(mutableListOf<Int>()) { output, value ->
            if (output.all { abs(it - value) > 8 } && output.size < 4) output.add(value)
            output
        }.sorted()
        return if (lows.size == 4) lows.map { it / 100f } else listOf(0.20f, 0.40f, 0.60f, 0.80f)
    }

    private fun yellowComponents(image: Bitmap): List<Triple<Float, Float, Float>> {
        val step = 3
        val width = image.width / step
        val height = image.height / step
        val mask = BooleanArray(width * height)
        for (y in 0 until height) for (x in 0 until width) {
            val color = image.getPixel(x * step, y * step)
            val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
            mask[y * width + x] = r > 125 && g > 110 && r > b + 25 && g > b + 15
        }
        val seen = BooleanArray(mask.size)
        val output = mutableListOf<Triple<Float, Float, Float>>()
        val queue = ArrayDeque<Int>()
        for (y in 1 until height - 1) for (x in 1 until width - 1) {
            val seed = y * width + x
            if (!mask[seed] || seen[seed]) continue
            seen[seed] = true; queue.add(seed)
            var sumX = 0L; var sumY = 0L; var count = 0
            var left = width; var right = 0; var top = height; var bottom = 0
            while (queue.isNotEmpty()) {
                val value = queue.removeFirst(); val px = value % width; val py = value / width
                sumX += px; sumY += py; count++
                left = minOf(left, px); right = maxOf(right, px)
                top = minOf(top, py); bottom = maxOf(bottom, py)
                for (next in intArrayOf(value - 1, value + 1, value - width, value + width)) {
                    if (next in mask.indices && mask[next] && !seen[next]) { seen[next] = true; queue.add(next) }
                }
            }
            val componentWidth = (right - left) * step
            val componentHeight = (bottom - top) * step
            val aspect = componentWidth.toFloat() / componentHeight.coerceAtLeast(1)
            // Exclude large yellow background regions, slender clips and
            // other objects before choosing the six target centres.
            val plausibleSize = componentWidth >= image.width * 0.022f &&
                componentHeight >= image.height * 0.045f &&
                componentWidth <= image.width * 0.19f &&
                componentHeight <= image.height * 0.23f
            val plausibleShape = aspect in 0.64f..1.55f
            val plausibleArea = count > 20 && count < width * height * 0.035f
            if (plausibleSize && plausibleShape && plausibleArea) {
                val radius = sqrt(count / Math.PI).toFloat() * step
                output.add(Triple(sumX.toFloat() / count * step, sumY.toFloat() / count * step, radius))
            }
        }
        return output.sortedByDescending { it.third }.take(6)
    }

    private data class ShaftPixel(
        val x: Int,
        val y: Int,
        val difference: Int,
        val darkness: Int,
        val normalizedRadius: Float
    )

    /**
     * Detects the silver/steel dart shaft, independent of the color of the
     * plastic head. The entry point is the endpoint of the elongated new
     * shaft component which lies toward the target centre.
     */
    private fun needle(start: Bitmap, end: Bitmap, target: TargetCal): Triple<Float, Float, Float>? {
        val result = HeadToShaftDetector.detect(start, end, target) ?: return null
        return Triple(result.x, result.y, result.confidence)
    }

    private data class FittedShaft(
        val entryX: Float,
        val entryY: Float,
        val entryRadius: Float,
        val length: Float,
        val elongation: Float,
        val meanDifference: Float
    )

    private fun shaftComponents(
        mask: BooleanArray,
        pixels: Array<ShaftPixel?>,
        width: Int,
        height: Int
    ): List<List<ShaftPixel>> {
        val seen = BooleanArray(mask.size)
        val output = mutableListOf<List<ShaftPixel>>()
        val queue = ArrayDeque<Int>()
        for (seed in mask.indices) {
            if (!mask[seed] || seen[seed]) continue
            seen[seed] = true
            queue.add(seed)
            val component = mutableListOf<ShaftPixel>()
            while (queue.isNotEmpty()) {
                val value = queue.removeFirst()
                pixels[value]?.let(component::add)
                val x = value % width
                val y = value / width
                // A 2-pixel bridge joins both edges of a thin anti-aliased shaft.
                for (dy in -2..2) for (dx in -2..2) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx; val ny = y + dy
                    if (nx !in 0 until width || ny !in 0 until height) continue
                    val next = ny * width + nx
                    if (mask[next] && !seen[next]) { seen[next] = true; queue.add(next) }
                }
            }
            if (component.isNotEmpty()) output.add(component)
        }
        return output
    }

    /** Follow the connected shaft pixels as a graph rather than extrapolating a PCA line.
     * Two graph sweeps approximate the longest visible path, including moderate bends.
     * Ambiguous heads and branched/noisy components are rejected.
     */
    private fun fitShaft(component: List<ShaftPixel>, target: TargetCal, start: Bitmap, end: Bitmap): FittedShaft? {
        if (component.size !in 9..2500) return null
        val byPosition = component.associateBy { it.y.toLong() * end.width + it.x }
        fun neighbors(pixel: ShaftPixel): List<ShaftPixel> {
            val result = ArrayList<ShaftPixel>(8)
            for (dy in -2..2) for (dx in -2..2) {
                if (dx == 0 && dy == 0 || dx * dx + dy * dy > 5) continue
                byPosition[(pixel.y + dy).toLong() * end.width + pixel.x + dx]?.let(result::add)
            }
            return result
        }
        // Breadth-first traversal over actual connected shaft pixels.
        fun farthest(origin: ShaftPixel): Pair<ShaftPixel, Map<Long, Long>> {
            val originKey = origin.y.toLong() * end.width + origin.x
            val queue = ArrayDeque<ShaftPixel>()
            val visited = HashSet<Long>()
            val parents = HashMap<Long, Long>()
            queue.add(origin); visited.add(originKey)
            var far = origin
            while (queue.isNotEmpty()) {
                val current = queue.removeFirst()
                far = current
                val key = current.y.toLong() * end.width + current.x
                for (next in neighbors(current)) {
                    val nk = next.y.toLong() * end.width + next.x
                    if (visited.add(nk)) { parents[nk] = key; queue.add(next) }
                }
            }
            return far to parents
        }
        val first = farthest(component.first()).first
        val (last, parents) = farthest(first)
        val firstKey = first.y.toLong() * end.width + first.x
        var cursor = last.y.toLong() * end.width + last.x
        val path = ArrayList<ShaftPixel>()
        val seen = HashSet<Long>()
        while (seen.add(cursor)) {
            val pixel = byPosition[cursor] ?: return null
            path.add(pixel)
            if (cursor == firstKey) break
            cursor = parents[cursor] ?: return null
        }
        if (path.size < 10 || path.last() != first) return null
        val span = hypot((last.x - first.x).toFloat(), (last.y - first.y).toFloat())
        val length = path.size.toFloat()
        // Reject broad blobs and excessive wandering caused by ring artefacts.
        if (span < maxOf(9f, target.rx * 0.09f) || length / span > 2.5f) return null
        val thickness = component.size.toFloat() / length
        if (thickness > maxOf(5f, target.rx * 0.07f)) return null
        val orientation = EntryPointEstimator.fromEndpoints(
            start, end, first.x.toFloat(), first.y.toFloat(),
            last.x.toFloat(), last.y.toFloat(), target.rx
        ) ?: return null
        val entryX = orientation.x
        val entryY = orientation.y
        val entryRadius = hypot((entryX - target.cx) / target.rx, (entryY - target.cy) / target.ry)
        if (entryRadius > 1.04f) return null
        return FittedShaft(entryX, entryY, entryRadius, length, span / thickness.coerceAtLeast(1f),
            path.map { it.difference }.average().toFloat())
    }

    private fun colorDistance(first: Int, second: Int): Int =
        abs(Color.red(first) - Color.red(second)) +
            abs(Color.green(first) - Color.green(second)) +
            abs(Color.blue(first) - Color.blue(second))

    private fun luma(color: Int): Int = (Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000
}
