package de.florian.blinksnapshot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

/** Head-first, reference-difference shaft detector. Uncertain paths never produce a score. */
object HeadToShaftDetector {
    data class Result(val x: Float, val y: Float, val confidence: Float)
    data class Diagnostic(
        val headCandidates: Int,
        val shaftPixels: Int,
        val result: Result?,
        val reason: String,
        val acceptedHeads: Int = 0,
        val bestPathLength: Int = 0,
        val bridges: Int = 0,
        val plausibleEndpoints: Int = 0,
        val projectionPixels: Float = 0f,
        val projectionError: Float = 0f,
        val shaftPath: List<Pair<Float, Float>> = emptyList(),
        val headPoint: Pair<Float, Float>? = null,
        val alternatives: List<Pair<Float, Float>> = emptyList()
    )
    private data class Head(val x: Float, val y: Float, val size: Int, val compactness: Float,
                            val colorStrength: Float)
    private data class Path(val endpoint: Int, val length: Int, val bridges: Int, val straightness: Float, val quality: Float)
    private data class Projected(val x: Float, val y: Float, val distance: Float, val error: Float)

    /** Project only a few pixels beyond the last real shaft pixel.
     * Use the last path segment, not a line through the entire (possibly bent) shaft.
     */
    private fun projectEnd(endpoint: Int, parents: IntArray, width: Int,
                           headX: Float, headY: Float, radius: Float): Projected? {
        val tail = ArrayList<Int>()
        var cursor = endpoint
        repeat(9) {
            if (cursor < 0) return@repeat
            tail.add(cursor)
            cursor = parents[cursor]
        }
        if (tail.size < 4) return null
        val near = tail.take(2)
        val far = tail.takeLast(2)
        val ax = near.map { (it % width).toFloat() }.average().toFloat()
        val ay = near.map { (it / width).toFloat() }.average().toFloat()
        val bx = far.map { (it % width).toFloat() }.average().toFloat()
        val by = far.map { (it / width).toFloat() }.average().toFloat()
        val dx = ax - bx; val dy = ay - by
        val length = hypot(dx, dy)
        if (length < 2f) return null
        // A local tangent must point away from the plastic head.
        val outward = dx * (ax - headX) + dy * (ay - headY)
        if (outward <= 0f) return null
        val ux = dx / length; val uy = dy / length
        val residual = near.map { kotlin.math.abs((it % width - ax) * uy - (it / width - ay) * ux) }
            .average().toFloat()
        if (residual > 3.5f) return null
        val distance = (radius * 0.035f).coerceIn(1.5f, 4f)
        return Projected(ax + ux * distance, ay + uy * distance, distance, residual)
    }

    fun detect(before: Bitmap, after: Bitmap, cal: TargetCal): Result? = inspect(before, after, cal).result

    /** V28: line evidence is sampled along rays, not required to form a connected path. */
    fun inspect(before: Bitmap, after: Bitmap, cal: TargetCal): Diagnostic {
        val w = minOf(before.width, after.width)
        val h = minOf(before.height, after.height)
        if (w < 30 || h < 30 || cal.rx < 5f || cal.ry < 5f)
            return Diagnostic(0, 0, null, "Bild oder Kalibrierung ungueltig")
        val left = (cal.cx - cal.rx * 1.38f).toInt().coerceIn(0, w - 1)
        val right = (cal.cx + cal.rx * 1.38f).toInt().coerceIn(left, w - 1)
        val top = (cal.cy - cal.ry * 1.38f).toInt().coerceIn(0, h - 1)
        val bottom = (cal.cy + cal.ry * 1.38f).toInt().coerceIn(top, h - 1)
        val rw = right - left + 1
        val rh = bottom - top + 1
        val n = rw * rh
        val headMask = BooleanArray(n)
        val shaftMask = BooleanArray(n)
        val hsv = FloatArray(3)
        // Estimate frame-wide luminance drift from sparse background samples.
        // The median resists individual shafts and coloured heads.
        val luminanceOffsets = ArrayList<Int>()
        for (yy in 0 until rh step 11) for (xx in 0 until rw step 11) {
            val gx = left + xx; val gy = top + yy
            if (hypot((gx-cal.cx)/cal.rx,(gy-cal.cy)/cal.ry) > 1.38f) continue
            val a = before.getPixel(gx,gy); val b = after.getPixel(gx,gy)
            val la = (3*Color.red(a)+6*Color.green(a)+Color.blue(a))/10
            val lb = (3*Color.red(b)+6*Color.green(b)+Color.blue(b))/10
            luminanceOffsets.add(lb-la)
        }
        luminanceOffsets.sort()
        val illuminationOffset = if (luminanceOffsets.isEmpty()) 0 else
            luminanceOffsets[luminanceOffsets.size/2].coerceIn(-30,30)
        for (y in 0 until rh) for (x in 0 until rw) {
            val gx = left + x; val gy = top + y
            if (hypot((gx - cal.cx) / cal.rx, (gy - cal.cy) / cal.ry) > 1.38f) continue
            val old = before.getPixel(gx, gy); val now = after.getPixel(gx, gy)
            val r = Color.red(now); val g = Color.green(now); val b = Color.blue(now)
            val change = abs(r - (Color.red(old)+illuminationOffset).coerceIn(0,255)) +
                abs(g - (Color.green(old)+illuminationOffset).coerceIn(0,255)) +
                abs(b - (Color.blue(old)+illuminationOffset).coerceIn(0,255))
            val chroma = maxOf(r,g,b) - minOf(r,g,b)
            val lum = (3*r + 6*g + b)/10
            val oldLum = (3*Color.red(old) + 6*Color.green(old) + Color.blue(old))/10
            Color.colorToHSV(now, hsv)
            val green = hsv[0] in 60f..175f
            val pink = hsv[0] in 285f..359f || hsv[0] in 0f..8f
            val i = y*rw+x
            // Dark green heads need lower saturation and brightness limits.
            // Require a real change from the empty reference to avoid printed rings.
            val colourChanged = change >= 36 &&
                (abs(g - Color.green(old)) >= 10 || change >= 65)
            headMask[i] = (green || pink) && hsv[1] > 0.18f &&
                hsv[2] > 0.10f && colourChanged
            shaftMask[i] = change >= 26 &&
                (oldLum + illuminationOffset - lum > 9 || (chroma < 58 && lum in 30..215)) &&
                !headMask[i]
        }
        data class HeadCandidate(val x: Float, val y: Float, val size: Int, val compact: Float)
        val seen = BooleanArray(n)
        val heads = ArrayList<HeadCandidate>()
        var rawHeads = 0
        for (seed in 0 until n) {
            if (!headMask[seed] || seen[seed]) continue
            val q = ArrayDeque<Int>(); q.add(seed); seen[seed] = true
            var count = 0; var sx = 0f; var sy = 0f
            var minX = rw; var maxX = 0; var minY = rh; var maxY = 0
            while (q.isNotEmpty()) {
                val v = q.removeFirst(); val x = v%rw; val y = v/rw
                count++; sx += x; sy += y
                minX = minOf(minX,x); maxX = maxOf(maxX,x)
                minY = minOf(minY,y); maxY = maxOf(maxY,y)
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x+dx; val ny = y+dy
                    if (nx !in 0 until rw || ny !in 0 until rh) continue
                    val ni = ny*rw+nx
                    if (headMask[ni] && !seen[ni]) { seen[ni]=true; q.add(ni) }
                }
            }
            if (count < 4) continue
            rawHeads++
            val bw = maxX-minX+1; val bh=maxY-minY+1
            val compact = count.toFloat()/(bw*bh)
            val aspect = maxOf(bw,bh).toFloat() / minOf(bw,bh).coerceAtLeast(1)
            if (count in 4..210 && maxOf(bw,bh) <= maxOf(9f,cal.rx*0.25f) &&
                compact >= .24f && aspect <= 3.0f)
                heads.add(HeadCandidate(sx/count,sy/count,count,compact))
        }
        // V31.2: reconstruct NEW elongated metallic components before searching heads.
        // Eight-connected flood fill keeps unrelated target ring fragments apart.
        data class MetalComponent(val pixels: List<Pair<Float,Float>>,
                                  val axisX: Float, val axisY: Float,
                                  val endA: Pair<Float,Float>, val endB: Pair<Float,Float>,
                                  val elongation: Float)
        val metals = ArrayList<MetalComponent>()
        val metalSeen = BooleanArray(n)
        for (seed in 0 until n) {
            if (!shaftMask[seed] || metalSeen[seed]) continue
            val queue = ArrayDeque<Int>(); queue.add(seed); metalSeen[seed] = true
            val pixels = ArrayList<Pair<Float,Float>>()
            while (queue.isNotEmpty()) {
                val at = queue.removeFirst(); val x = at % rw; val y = at / rw
                pixels.add(Pair((x+left).toFloat(),(y+top).toFloat()))
                if (pixels.size > 500) break
                for (dy in -1..1) for (dx in -1..1) {
                    val xx=x+dx; val yy=y+dy
                    if (xx !in 0 until rw || yy !in 0 until rh) continue
                    val ni=yy*rw+xx
                    if (shaftMask[ni] && !metalSeen[ni]) {
                        metalSeen[ni]=true; queue.add(ni)
                    }
                }
            }
            if (pixels.size !in 7..250) continue
            val mx=pixels.map { it.first }.average().toFloat()
            val my=pixels.map { it.second }.average().toFloat()
            var xx=0.0; var xy=0.0; var yy=0.0
            for (point in pixels) {
                val dx=(point.first-mx).toDouble(); val dy=(point.second-my).toDouble()
                xx+=dx*dx; xy+=dx*dy; yy+=dy*dy
            }
            val theta=.5*kotlin.math.atan2(2.0*xy,xx-yy)
            val vx=kotlin.math.cos(theta).toFloat()
            val vy=kotlin.math.sin(theta).toFloat()
            val projections=pixels.map { (it.first-mx)*vx+(it.second-my)*vy }
            val lo=projections.minOrNull() ?: continue
            val hi=projections.maxOrNull() ?: continue
            val span=hi-lo
            val thickness=pixels.size.toFloat()/span.coerceAtLeast(1f)
            if (span < 9f || thickness > 4.2f) continue
            val a=Pair(mx+vx*lo,my+vy*lo)
            val b=Pair(mx+vx*hi,my+vy*hi)
            metals.add(MetalComponent(pixels,vx,vy,a,b,span/thickness.coerceAtLeast(.5f)))
        }
        val shaftCount = shaftMask.count { it }
        if (heads.isEmpty()) return Diagnostic(rawHeads,shaftCount,null,"Kein gruen/pinker Kopf",0)
        // V30.3: SHAFT-FIRST. A line is proposed from changed metallic pixels,
        // then one of its ends must be associated with a new green/pink head.
        // The red hand-drawn training annotations are NEVER used as live input.
        data class ShaftHypothesis(
            val tip: Pair<Float, Float>, val head: HeadCandidate,
            val quality: Float, val support: Int,
            val trace: List<Pair<Float, Float>>,
            val angle: Float
        )
        // Geometric reconstruction: robust total-least-squares axis from the
        // actual changed shaft pixels, not from the endpoints of a Hough ray.
        // The red annotation is not accessed by this method.
        fun reconstructAxis(points: List<Pair<Float,Float>>, head: HeadCandidate): Pair<Pair<Float,Float>,List<Pair<Float,Float>>>? {
            if (points.size < 12) return null
            var kept = points
            var vx = 1f; var vy = 0f
            var mx = 0f; var my = 0f
            repeat(3) { iteration ->
                if (kept.size < 10) return null
                mx = kept.map { it.first }.average().toFloat()
                my = kept.map { it.second }.average().toFloat()
                var xx = 0.0; var xy = 0.0; var yy = 0.0
                for (pt in kept) {
                    val a = (pt.first-mx).toDouble(); val b = (pt.second-my).toDouble()
                    xx += a*a; xy += a*b; yy += b*b
                }
                val theta = .5 * kotlin.math.atan2(2.0*xy,xx-yy)
                vx = kotlin.math.cos(theta).toFloat(); vy = kotlin.math.sin(theta).toFloat()
                if (iteration < 2) kept = kept.filter {
                    kotlin.math.abs((it.first-mx)*vy-(it.second-my)*vx) <= 2.3f
                }
            }
            if (kept.size < 10) return null
            val projections = kept.map { (it.first-mx)*vx+(it.second-my)*vy }
            val low = projections.minOrNull() ?: return null
            val high = projections.maxOrNull() ?: return null
            if (high-low < 12f) return null
            val a = Pair(mx+vx*low,my+vy*low)
            val b = Pair(mx+vx*high,my+vy*high)
            val da = hypot(a.first-(head.x+left),a.second-(head.y+top))
            val db = hypot(b.first-(head.x+left),b.second-(head.y+top))
            if (minOf(da,db) > 10f) return null
            val tip = if (da <= db) b else a
            if (hypot((tip.first-cal.cx)/cal.rx,(tip.second-cal.cy)/cal.ry) > 1.04f) return null
            return Pair(tip,kept)
        }
        // V32: Conservative extension of the V32.3 observed shaft endpoint.
        // The long extension is accepted only with independent, dense evidence
        // beyond the original endpoint and without long gaps.
        fun verifiedExtension(tip: Pair<Float,Float>, headX: Float, headY: Float): Pair<Float,Float> {
            val dx = tip.first-headX; val dy = tip.second-headY
            val len = hypot(dx,dy)
            if (len < 9f) return tip
            val ux = dx/len; val uy = dy/len
            var last = tip
            var misses = 0
            var newPixels = 0
            var total = 0
            var firstEvidence = false
            var run = 0
            var longestRun = 0
            for (step in 1..45) {
                val px = kotlin.math.round(tip.first + ux*step).toInt()-left
                val py = kotlin.math.round(tip.second + uy*step).toInt()-top
                if (px !in 2 until rw-2 || py !in 2 until rh-2) break
                var evidence = 0
                for (side in -1..1) {
                    val sx = px + kotlin.math.round(-uy*side).toInt()
                    val sy = py + kotlin.math.round(ux*side).toInt()
                    if (sx in 0 until rw && sy in 0 until rh && shaftMask[sy*rw+sx]) evidence++
                }
                total++
                if (evidence >= 2) {
                    if (step <= 5) firstEvidence = true
                    newPixels++
                    misses = 0
                    run++
                    longestRun = maxOf(longestRun,run)
                    last = Pair((px+left).toFloat(),(py+top).toFloat())
                } else {
                    misses++
                    run = 0
                }
                if (misses >= 4) break
            }
            // Guard against accidental continuation along an existing ring.
            // Require a strong near-tip attachment and substantial sustained
            // evidence in the extra pixels, not merely one isolated pixel.
            if (!firstEvidence || total < 6 || newPixels < 6 || longestRun < 4 ||
                newPixels.toFloat()/total < .60f) return tip
            // Compare independent short and long traces.  Do not replace the
            // original point if the new end is unsupported by the shaft axis.
            val extensionLength = hypot(last.first-tip.first,last.second-tip.second)
            if (extensionLength < 3f || extensionLength > 45f) return tip
            val lateralError = kotlin.math.abs((last.first-tip.first)*uy - (last.second-tip.second)*ux)
            if (lateralError > 2.5f) return tip
            if (hypot((last.first-cal.cx)/cal.rx,(last.second-cal.cy)/cal.ry)>1.04f) return tip
            return last
        }
        // V33: independent left/right shaft-boundary evidence in the new-pixel mask.
        // This is a verification pass, not a replacement for the baseline detector.
        data class EdgeCheck(val tip: Pair<Float,Float>, val support: Int, val paired: Int)
        fun doubleEdgeCheck(tip: Pair<Float,Float>, headX: Float, headY: Float): EdgeCheck? {
            val dx=tip.first-headX; val dy=tip.second-headY
            val length=hypot(dx,dy)
            if (length<16f) return null
            val ux=dx/length; val uy=dy/length
            val nx=-uy; val ny=ux
            var paired=0; var leftSum=0f; var rightSum=0f
            var last=tip
            var lastT=0f
            val limit=(length-4f).toInt()
            for (t in 9..limit step 2) {
                val cx=headX+ux*t; val cy=headY+uy*t
                var leftEdge: Float?=null; var rightEdge: Float?=null
                // Both sides must be independently supported by new shaft pixels.
                for (side in 1..6) {
                    val lx=kotlin.math.round(cx+nx*side).toInt()-left
                    val ly=kotlin.math.round(cy+ny*side).toInt()-top
                    val rx=kotlin.math.round(cx-nx*side).toInt()-left
                    val ry=kotlin.math.round(cy-ny*side).toInt()-top
                    if (lx in 0 until rw && ly in 0 until rh && shaftMask[ly*rw+lx]) leftEdge=side.toFloat()
                    if (rx in 0 until rw && ry in 0 until rh && shaftMask[ry*rw+rx]) rightEdge=side.toFloat()
                }
                if (leftEdge!=null && rightEdge!=null) {
                    val width=leftEdge+rightEdge
                    if (width in 2f..10f) {
                        paired++
                        leftSum+=leftEdge; rightSum+=rightEdge
                        lastT=t.toFloat()
                        last=Pair(cx+nx*(leftEdge-rightEdge)/2f,cy+ny*(leftEdge-rightEdge)/2f)
                    }
                }
            }
            if (paired<5 || lastT<length*.55f) return null
            val asymmetry=kotlin.math.abs(leftSum-rightSum)/paired
            if (asymmetry>3f) return null
            return EdgeCheck(last,paired*2,paired)
        }
        // Local metal-to-paper transition: check the final pixels along the
        // already selected axis, ignoring isolated single-pixel changes.
        fun localEndCheck(tip: Pair<Float,Float>, headX: Float, headY: Float): Pair<Float,Float>? {
            val dx=tip.first-headX;val dy=tip.second-headY
            val len=hypot(dx,dy);if (len<10f)return null
            val ux=dx/len;val uy=dy/len
            var best: Pair<Float,Float>?=null
            var bestRun=0
            for (offset in -12..12) {
                val qx=tip.first+ux*offset;val qy=tip.second+uy*offset
                val px=kotlin.math.round(qx).toInt()-left
                val py=kotlin.math.round(qy).toInt()-top
                if (px !in 2 until rw-2 || py !in 2 until rh-2)continue
                var run=0
                for (back in 0..5) {
                    val bx=kotlin.math.round(qx-ux*back).toInt()-left
                    val by=kotlin.math.round(qy-uy*back).toInt()-top
                    if (bx in 0 until rw && by in 0 until rh && shaftMask[by*rw+bx])run++
                }
                var beyond=0
                for (forward in 2..5) {
                    val fx=kotlin.math.round(qx+ux*forward).toInt()-left
                    val fy=kotlin.math.round(qy+uy*forward).toInt()-top
                    if (fx in 0 until rw && fy in 0 until rh && shaftMask[fy*rw+fx])beyond++
                }
                if (run>=4 && beyond<=1 && (run>bestRun || (run==bestRun && best==null))) {
                    bestRun=run;best=Pair(qx,qy)
                }
            }
            return best
        }
        fun hybridEndpoint(tip: Pair<Float,Float>, headX: Float, headY: Float): Pair<Float,Float> {
            val dual=doubleEdgeCheck(tip,headX,headY)
            val extended=verifiedExtension(tip,headX,headY)
            val extendedDistance=hypot(extended.first-tip.first,extended.second-tip.second)
            // Strong two-sided evidence must agree with the original endpoint.
            // Never move a correct baseline tip simply because a short pair ends early.
            if (dual!=null && extendedDistance<=2f &&
                hypot(dual.tip.first-tip.first,dual.tip.second-tip.second)<=5f) return tip
            if (extendedDistance>2f) {
                // A long extension is only accepted when the independent paired
                // boundary check does not contradict the direction of travel.
                if (dual!=null && dual.paired>=6) {
                    val ux=(tip.first-headX)/hypot(tip.first-headX,tip.second-headY)
                    val uy=(tip.second-headY)/hypot(tip.first-headX,tip.second-headY)
                    val lateral=kotlin.math.abs((extended.first-tip.first)*uy-(extended.second-tip.second)*ux)
                    if (lateral<=2.5f) return extended
                }
                return tip
            }
            // Only consider local correction if the two-sided check strongly
            // disagrees with the baseline. Avoid speculative changes otherwise.
            if (dual!=null && dual.paired>=6 &&
                hypot(dual.tip.first-tip.first,dual.tip.second-tip.second)>6f) {
                val local=localEndCheck(tip,headX,headY)
                if (local!=null && hypot(local.first-tip.first,local.second-tip.second)<=5f &&
                    hypot(local.first-dual.tip.first,local.second-dual.tip.second)<=6f) return local
            }
            return tip
        }
        val shaftHypotheses = ArrayList<ShaftHypothesis>()
        // Validate metal components by the presence of a coloured head at ONE end.
        // The other observed end becomes the tentative insertion point.
        for (metal in metals) {
            val nearestA=heads.minByOrNull { hypot(it.x+left-metal.endA.first,it.y+top-metal.endA.second) }
            val nearestB=heads.minByOrNull { hypot(it.x+left-metal.endB.first,it.y+top-metal.endB.second) }
            val distA=nearestA?.let { hypot(it.x+left-metal.endA.first,it.y+top-metal.endA.second) } ?: 999f
            val distB=nearestB?.let { hypot(it.x+left-metal.endB.first,it.y+top-metal.endB.second) } ?: 999f
            val head=if (distA<=distB) nearestA else nearestB
            val distance=minOf(distA,distB)
            if (head==null || distance>9f) continue
            val tip=if (distA<=distB) metal.endB else metal.endA
            if (hypot((tip.first-cal.cx)/cal.rx,(tip.second-cal.cy)/cal.ry)>1.04f) continue
            val quality=metal.elongation.coerceAtMost(30f)*1.5f +
                metal.pixels.size.coerceAtMost(60)*.25f + head.compact*8f - distance*2f
            val verifiedTip = hybridEndpoint(tip,head.x+left,head.y+top)
            shaftHypotheses.add(ShaftHypothesis(verifiedTip,head,quality,
                metal.pixels.size,metal.pixels,
                kotlin.math.atan2(metal.axisY,metal.axisX).toFloat()))
        }
        val maxTrace = (cal.rx * 0.95f).toInt().coerceIn(18, 115)
        val sampleStride = 4
        // Candidate endpoints are clustered so many near-identical sampled rays
        // count as ONE shaft rather than independent evidence.
        // Sparse seeds limit the cost on a full-resolution camera frame.
        if (shaftHypotheses.isEmpty()) for (sy in 2 until rh-2 step sampleStride) for (sx in 2 until rw-2 step sampleStride) {
            if (!shaftMask[sy * rw + sx]) continue
            for (degrees in 0 until 180 step 9) {
                val angle = Math.toRadians(degrees.toDouble())
                val dx = kotlin.math.cos(angle).toFloat()
                val dy = kotlin.math.sin(angle).toFloat()
                val evidence = ArrayList<Pair<Float, Float>>()
                var first = -1
                var last = -1
                var support = 0
                var longestGap = 0
                var currentGap = 0
                for (t in -maxTrace..maxTrace) {
                    val xx = (sx + dx*t).toInt()
                    val yy = (sy + dy*t).toInt()
                    if (xx !in 1 until rw-1 || yy !in 1 until rh-1) continue
                    var found = false
                    for (offset in -1..1) {
                        val px = (xx - dy*offset).toInt()
                        val py = (yy + dx*offset).toInt()
                        if (px in 0 until rw && py in 0 until rh && shaftMask[py*rw+px]) {
                            found = true; break
                        }
                    }
                    if (found) {
                        if (first < 0) first = t
                        last = t; support++
                        longestGap = maxOf(longestGap,currentGap)
                        currentGap = 0
                        evidence.add(Pair((xx+left).toFloat(),(yy+top).toFloat()))
                    } else if (first >= 0) currentGap++
                }
                if (first < 0 || last-first < 13 || support < 12 || longestGap > 7) continue
                val span = last-first
                val density = support.toFloat()/(span+1)
                if (density < .53f) continue
                val ax = sx + dx*first; val ay = sy + dy*first
                val bx = sx + dx*last; val by = sy + dy*last
                val headA = heads.minByOrNull { hypot(it.x-ax,it.y-ay) }
                val headB = heads.minByOrNull { hypot(it.x-bx,it.y-by) }
                val distA = headA?.let { hypot(it.x-ax,it.y-ay) } ?: 999f
                val distB = headB?.let { hypot(it.x-bx,it.y-by) } ?: 999f
                val chosen = if (distA <= distB) headA else headB
                val distance = minOf(distA,distB)
                if (chosen == null || distance > 7f) continue
                // Require actual metallic evidence immediately adjacent to the head.
                // Reject distant ring edges even if their extended axis meets a head.
                val headX = if (distA <= distB) ax else bx
                val headY = if (distA <= distB) ay else by
                var nearSupport = 0
                val towardX = if (distA <= distB) dx else -dx
                val towardY = if (distA <= distB) dy else -dy
                for (step in 2..12) {
                    val qx = (headX + towardX*step).toInt()
                    val qy = (headY + towardY*step).toInt()
                    if (qx in 0 until rw && qy in 0 until rh && shaftMask[qy*rw+qx]) nearSupport++
                }
                if (nearSupport < 3) continue
                val tipX = if (distA <= distB) bx else ax
                val tipY = if (distA <= distB) by else ay
                // Tip must be on the calibrated target, not on the surrounding wall.
                if (hypot((tipX+left-cal.cx)/cal.rx,(tipY+top-cal.cy)/cal.ry) > 1.04f) continue
                // Printed rings are tangential to the target centre. A shaft
                // supported mainly by a ring tangent is a poor hypothesis.
                val midX = (ax+bx)*.5f+left
                val midY = (ay+by)*.5f+top
                val radialX = (midX-cal.cx)/cal.rx
                val radialY = (midY-cal.cy)/cal.ry
                val radialLength = hypot(radialX,radialY)
                val tangentAlignment = if (radialLength > .08f) {
                    kotlin.math.abs((-radialY*dx+radialX*dy)/radialLength)
                } else 0f
                // Reject only strongly tangential tracks near a known ring.
                val normRadius = radialLength
                val onRing = listOf(.2f,.4f,.6f,.8f,1f).any {
                    kotlin.math.abs(normRadius-it) < .045f
                }
                if (onRing && tangentAlignment > .93f) continue
                val quality = density*45f + span.toFloat()/maxTrace*12f - longestGap*1.8f +
                    chosen.compact*8f + nearSupport*1.2f - distance*2.2f -
                    (if (onRing) tangentAlignment*12f else 0f)
                val geometry = reconstructAxis(evidence,chosen) ?: continue
                // The endpoint comes from a robust fit to observed shaft pixels.
                // Do not extrapolate an arbitrary Hough segment into the target.
                val verifiedTip = hybridEndpoint(geometry.first,chosen.x+left,chosen.y+top)
                shaftHypotheses.add(ShaftHypothesis(
                    verifiedTip,chosen,quality,geometry.second.size,geometry.second,
                    angle.toFloat()
                ))
            }
        }
        // Non-maximum suppression: collapse the repeated detections of one
        // shaft (same head, direction and tip) before ranking competitors.
        val rankedShafts = ArrayList<ShaftHypothesis>()
        for (candidate in shaftHypotheses.sortedByDescending { it.quality }) {
            if (rankedShafts.size >= 24) break
            val duplicate = rankedShafts.any { existing ->
                hypot(candidate.head.x-existing.head.x,
                      candidate.head.y-existing.head.y) <= 7f &&
                hypot(candidate.tip.first-existing.tip.first,
                      candidate.tip.second-existing.tip.second) <= maxOf(6f,cal.rx*.055f) &&
                kotlin.math.abs(kotlin.math.sin((candidate.angle-existing.angle).toDouble())) < .22
            }
            if (!duplicate) rankedShafts.add(candidate)
        }
        if (rankedShafts.isNotEmpty()) {
            val bestShaft = rankedShafts.first()
            val competing = rankedShafts.drop(1).filter {
                it.quality >= bestShaft.quality * .82f &&
                hypot(it.tip.first-bestShaft.tip.first,it.tip.second-bestShaft.tip.second) >
                    maxOf(6f,cal.rx*.07f)
            }
            val headLocation = Pair(bestShaft.head.x+left,bestShaft.head.y+top)
            if (competing.isNotEmpty()) return Diagnostic(
                rawHeads,shaftCount,null,"Schaftachsen mehrdeutig",heads.size,
                bestShaft.support,0,rankedShafts.size,0f,0f,
                bestShaft.trace,headLocation,competing.take(5).map { it.tip }
            )
            val confidence = (.35f+bestShaft.quality/350f).coerceIn(.35f,.60f)
            return Diagnostic(rawHeads,shaftCount,
                Result(bestShaft.tip.first,bestShaft.tip.second,confidence),
                "Schaft zuerst, Kopf am Gegenende",heads.size,
                bestShaft.support,0,rankedShafts.size,0f,0f,
                bestShaft.trace,headLocation,emptyList())
        }
        // If the independent shaft-first stage finds nothing, use the
        // existing head-anchored segment method as a conservative fallback.
        // Segment-based shaft model. Individual runs are joined only when they
        // share an axis, progress away from the head, and have short gaps.
        data class Segment(val from: Float, val to: Float, val pixels: Int)
        data class Line(val head: HeadCandidate, val angle: Double, val end: Float,
                        val quality: Float, val samples: Int, val points: List<Pair<Float,Float>>,
                        val joinedSegments: Int)
        val lines = ArrayList<Line>()
        // Do not discard a small genuine head before testing its shaft attachment.
        for (head in heads.sortedByDescending { it.size*it.compact }.take(35)) {
            val maxLength = (cal.rx * 0.85f).coerceIn(16f,140f)
            val start = (sqrt(head.size.toFloat())*.65f).coerceIn(2f,8f)
            for (degrees in 0 until 360 step 3) {
                val angle = Math.toRadians(degrees.toDouble())
                val ux = kotlin.math.cos(angle).toFloat()
                val uy = kotlin.math.sin(angle).toFloat()
                val samples = ArrayList<Pair<Float,Float>>()
                val segments = ArrayList<Segment>()
                var runStart = -1f; var runEnd = -1f; var runPixels = 0
                var distance = start
                while (distance <= maxLength) {
                    val fx = head.x + ux*distance
                    val fy = head.y + uy*distance
                    val cx = fx.toInt(); val cy = fy.toInt()
                    if (cx !in 2 until rw-2 || cy !in 2 until rh-2) break
                    val gx = cx+left; val gy = cy+top
                    if (hypot((gx-cal.cx)/cal.rx,(gy-cal.cy)/cal.ry) > 1.38f) break
                    var evidence = false
                    // A narrow, subpixel-oriented cross-section tolerates the
                    // 1.5-mm shaft without admitting wide circular ring edges.
                    for (offset in -1..1) {
                        val nx = (fx-uy*offset).toInt()
                        val ny = (fy+ux*offset).toInt()
                        if (nx in 0 until rw && ny in 0 until rh && shaftMask[ny*rw+nx]) evidence=true
                    }
                    if (evidence) {
                        if (runStart < 0f) runStart = distance
                        runEnd = distance; runPixels++
                        samples.add(Pair(gx.toFloat(),gy.toFloat()))
                    } else if (runStart >= 0f) {
                        if (runPixels >= 2) segments.add(Segment(runStart,runEnd,runPixels))
                        runStart = -1f; runPixels = 0
                    }
                    distance += 1f
                }
                if (runStart >= 0f && runPixels >= 2) segments.add(Segment(runStart,runEnd,runPixels))
                if (segments.isEmpty()) continue
                val ordered = segments.sortedBy { it.from }
                val headGap = (ordered.first().from-start)
                // A coloured spot without an immediate metal connection is not a head.
                if (headGap > 5f || ordered.first().pixels < 3) continue
                var lastEnd = ordered.first().to
                var support = ordered.first().pixels
                var joined = 1
                var gaps = 0f
                for (segment in ordered.drop(1)) {
                    val gap = segment.from-lastEnd
                    if (gap > 6f || joined >= 9) break
                    lastEnd = segment.to
                    support += segment.pixels
                    gaps += gap.coerceAtLeast(0f)
                    joined++
                }
                val span = lastEnd-start
                val density = support/span.coerceAtLeast(1f)
                if (span < maxOf(10f,cal.rx*.11f) || support < 9 || density < .48f) continue
                val selectedPoints = samples.filter { point ->
                    hypot(point.first-(head.x+left),point.second-(head.y+top)) <= lastEnd+1f
                }
                // Rank the head and its shaft as one hypothesis, not separately.
                val sizeScore = sqrt(head.size.toFloat()).coerceAtMost(12f)
                val attachmentScore = (7f-headGap).coerceIn(0f,7f)
                val quality = density*35f + (span/maxLength)*18f +
                    head.compact*7f + sizeScore*.7f + attachmentScore*2.2f -
                    gaps*1.5f - headGap*2.0f
                lines.add(Line(head,angle,lastEnd,quality,support,selectedPoints,joined))
            }
        }
        if (lines.isEmpty()) return Diagnostic(rawHeads,shaftCount,null,
            "Kein gerader Schaft mit ausreichend Linienpixeln",heads.size)
        val ranked = lines.sortedByDescending { it.quality }
        val best = ranked.first()
        fun endpoint(line: Line): Pair<Float,Float> {
            val x = line.head.x + kotlin.math.cos(line.angle).toFloat()*line.end + left
            val y = line.head.y + kotlin.math.sin(line.angle).toFloat()*line.end + top
            return Pair(x,y)
        }
        val bestEnd = endpoint(best)
        // Suppress near-identical rays of the same head; only a distinct endpoint
        // with comparable joint head/shaft quality is a competing hypothesis.
        val alternatives = ranked.drop(1).filter {
            val other = endpoint(it)
            hypot(other.first-bestEnd.first,other.second-bestEnd.second) > maxOf(5f,cal.rx*.07f) &&
                it.quality >= best.quality*.85f
        }
        val overlay = best.points
        if (alternatives.isNotEmpty()) return Diagnostic(rawHeads,shaftCount,null,
            "Mehrere gleichwertige Schaftachsen",heads.size,best.samples,best.joinedSegments-1,ranked.size,0f,0f,
            overlay,Pair(best.head.x+left,best.head.y+top),alternatives.take(5).map(::endpoint))
        val confidence = (.35f + (best.quality/75f)*.20f).coerceIn(.35f,.60f)
        return Diagnostic(rawHeads,shaftCount,Result(bestEnd.first,bestEnd.second,confidence),
            "Kopf-Schaft gemeinsam bewertet",heads.size,best.samples,best.joinedSegments-1,ranked.size,0f,0f,
            overlay,Pair(best.head.x+left,best.head.y+top),emptyList())
    }
}
