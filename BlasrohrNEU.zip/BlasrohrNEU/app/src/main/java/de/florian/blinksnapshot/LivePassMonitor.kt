package de.florian.blinksnapshot

import android.graphics.Bitmap
import kotlin.math.hypot

/** A per-target temporal tracker. No score is persisted until the user reviews it. */
class LivePassMonitor(private val reference: Bitmap, private val calibration: List<TargetCal>) {
    data class Slot(
        var hit: Hit? = null,
        var candidate: Hit? = null,
        var streak: Int = 0,
        val samples: MutableList<Hit> = mutableListOf(),
        var presenceStreak: Int = 0,
        var absenceStreak: Int = 0,
        var arrowPresent: Boolean = false,
        var changedPixels: Int = 0,
        var headCandidates: Int = 0,
        var shaftPixels: Int = 0,
        var diagnosis: String = "Noch keine Analyse",
        var acceptedHeads: Int = 0,
        var bestPathLength: Int = 0,
        var bridgeCount: Int = 0,
        var plausibleEndpoints: Int = 0,
        var projectionPixels: Float = 0f,
        var projectionError: Float = 0f,
        var debugPath: List<Pair<Float, Float>> = emptyList(),
        var debugHead: Pair<Float, Float>? = null,
        var debugAlternatives: List<Pair<Float, Float>> = emptyList(),
        var clusterCount: Int = 0,
        var bestClusterVotes: Int = 0,
        var trackedHead: Pair<Float, Float>? = null,
        var lastConfirmedPoint: Pair<Float, Float>? = null
    )
    val slots = List(6) { Slot() }
    val detected: Int get() = slots.count { it.hit != null }

    fun accept(frame: Bitmap): List<Hit?> {
        val aligned = Vision.align(reference, frame)
        try {
            val scaled = calibration.map { c ->
                val sx = reference.width.toFloat() / c.imageWidth.coerceAtLeast(1)
                val sy = reference.height.toFloat() / c.imageHeight.coerceAtLeast(1)
                c.copy(cx = c.cx * sx, cy = c.cy * sy, rx = c.rx * sx, ry = c.ry * sy,
                    imageWidth = reference.width, imageHeight = reference.height)
            }
            for (i in 0 until 6) {
                val slot = slots[i]
                val evidence = ArrowPresenceDetector.detect(reference, aligned.bitmap, scaled[i])
                slot.changedPixels = evidence.changedPixels
                if (evidence.present) {
                    slot.presenceStreak++
                    slot.absenceStreak = 0
                } else {
                    slot.absenceStreak++
                    slot.presenceStreak = 0
                }
                if (slot.presenceStreak >= 3) slot.arrowPresent = true
                // Latched for this pass: transient light/contrast changes cannot erase it.
                val diagnostic = HeadToShaftDetector.inspect(reference, aligned.bitmap, scaled[i])
                slot.headCandidates = diagnostic.headCandidates
                slot.shaftPixels = diagnostic.shaftPixels
                slot.diagnosis = diagnostic.reason
                slot.acceptedHeads = diagnostic.acceptedHeads
                slot.bestPathLength = diagnostic.bestPathLength
                slot.bridgeCount = diagnostic.bridges
                slot.plausibleEndpoints = diagnostic.plausibleEndpoints
                slot.projectionPixels = diagnostic.projectionPixels
                slot.projectionError = diagnostic.projectionError
                slot.debugPath = diagnostic.shaftPath
                slot.debugHead = diagnostic.headPoint
                slot.debugAlternatives = diagnostic.alternatives
                // Do not keep a confirmed hit if the current head/shaft geometry
                // contradicts it. A stale cluster must not remain authoritative.
                if (slot.hit != null) {
                    val current = diagnostic.result
                    val oldHit = slot.hit
                    val maxDrift = (scaled[i].rx * .07f).coerceIn(5f, 13f)
                    if (current == null || oldHit?.x == null || oldHit.y == null ||
                        hypot(current.x - oldHit.x!!, current.y - oldHit.y!!) > maxDrift) {
                        slot.hit = null
                        slot.samples.clear()
                        slot.clusterCount = 0
                        slot.bestClusterVotes = 0
                        slot.streak = 0
                        slot.candidate = null
                        slot.trackedHead = null
                    } else continue
                }
                val result = diagnostic.result?.let { candidate ->
                    val c = scaled[i]
                    val r = hypot((candidate.x - c.cx) / c.rx, (candidate.y - c.cy) / c.ry)
                    val score = when {
                        r <= c.rings[0] -> 10
                        r <= c.rings[1] -> 9
                        r <= c.rings[2] -> 8
                        r <= c.rings[3] -> 7
                        r <= 1.04f -> 6
                        else -> 0
                    }
                    Hit(i + 1, score, score, candidate.x, candidate.y, candidate.confidence)
                }
                // Collect non-consecutive observations. A missing candidate does not
                // erase previously seen plausible entry points.
                val head = diagnostic.headPoint
                if (!slot.arrowPresent || result?.x == null || result.y == null ||
                    result.confidence < 0.35f || head == null) {
                    slot.candidate = null
                    continue
                }
                val headTolerance = (scaled[i].rx * .07f).coerceIn(5f, 13f)
                val oldHead = slot.trackedHead
                if (oldHead != null && hypot(head.first-oldHead.first,head.second-oldHead.second) > headTolerance) {
                    slot.samples.clear()
                    slot.hit = null
                    slot.clusterCount = 0
                    slot.bestClusterVotes = 0
                }
                slot.trackedHead = head
                // Only collect positions tied to the currently tracked head.
                slot.samples.add(result)
                if (slot.samples.size > 24) slot.samples.removeAt(0)
                val radius = scaled[i].rx
                val tolerance = (radius * 0.055f).coerceIn(4f, 12f)
                // Cluster by spatial proximity, independently of visible shaft length.
                val clusters = mutableListOf<MutableList<Hit>>()
                for (sample in slot.samples) {
                    val x = sample.x ?: continue
                    val y = sample.y ?: continue
                    val cluster = clusters.firstOrNull { group ->
                        val cx = group.mapNotNull { it.x }.average().toFloat()
                        val cy = group.mapNotNull { it.y }.average().toFloat()
                        hypot(x - cx, y - cy) <= tolerance
                    }
                    if (cluster == null) clusters.add(mutableListOf(sample)) else cluster.add(sample)
                }
                slot.clusterCount = clusters.size
                val ranked = clusters.sortedByDescending { it.size }
                val best = ranked.firstOrNull()
                slot.bestClusterVotes = best?.size ?: 0
                slot.streak = slot.bestClusterVotes
                if (best != null) {
                    val xs = best.mapNotNull { it.x }.sorted()
                    val ys = best.mapNotNull { it.y }.sorted()
                    val scoreVotes = best.groupingBy { it.score }.eachCount()
                    val dominant = scoreVotes.maxByOrNull { it.value }
                    val candidate = best.last().copy(
                        x = xs[xs.size / 2], y = ys[ys.size / 2],
                        score = dominant?.key ?: best.last().score
                    )
                    slot.candidate = candidate
                    // Three measurements suffice, but do not accept an equally
                    // supported distant alternative or conflicting ring scores.
                    val competing = ranked.drop(1).any { it.size >= best.size }
                    if (best.size >= 3 && !competing && dominant != null && dominant.value >= 2 &&
                        diagnostic.result != null &&
                        hypot(candidate.x!! - diagnostic.result.x, candidate.y!! - diagnostic.result.y) <= tolerance) {
                        slot.lastConfirmedPoint = Pair(candidate.x!!, candidate.y!!)
                        slot.hit = candidate.copy(
                            confidence = (best.map { it.confidence }.average().toFloat() * 0.92f)
                                .coerceAtMost(0.72f)
                        )
                    }
                }
            }
        } finally {
            aligned.bitmap.recycle()
        }
        return slots.map { it.hit }
    }
}
