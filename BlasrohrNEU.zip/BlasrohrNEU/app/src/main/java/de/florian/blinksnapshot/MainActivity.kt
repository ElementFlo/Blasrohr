package de.florian.blinksnapshot

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.os.Bundle
import android.content.res.Configuration
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.os.CountDownTimer
import android.view.TextureView
import android.widget.*
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.*
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    private lateinit var db: TrainingDatabase
    private lateinit var store: CalStore
    private lateinit var player: ExoPlayer
    private lateinit var status: TextView
    private var trainingId = -1L
    private var calibration = emptyList<TargetCal>()
    private var monitor: LivePassMonitor? = null
    private var reference: Bitmap? = null
    private var loop: Job? = null
    private var timer: CountDownTimer? = null
    private var running = false
    private var reviewing = false
    private lateinit var dashboard: LiveDashboard
    private var lastDisplayFrame: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        installSystemBarInsets()
        db = TrainingDatabase(this)
        store = CalStore(this)
        calibration = store.load()
        status = findViewById(R.id.status)
        dashboard = LiveDashboard(this, findViewById(R.id.liveGrid))
        dashboard.onDetails = { index -> showTargetDetails(index) }
        val pages = findViewById<ViewFlipper>(R.id.pages)
        findViewById<RadioGroup>(R.id.tabs).setOnCheckedChangeListener { _, id ->
            pages.displayedChild = when(id) { R.id.t2 -> 1; R.id.t3 -> 2; R.id.t4 -> 3; R.id.t5 -> 4; else -> 0 }
            // Keep the actual RTSP TextureView attached to the visible page.
            if (id == R.id.t3 || (id == R.id.t2 && !running)) {
                moveCameraView(toRun = id == R.id.t3)
            }
        }
        findViewById<Spinner>(R.id.passGoal).adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, listOf("5 Passen", "10 Passen")
        )
        findViewById<Button>(R.id.create).setOnClickListener { createTraining() }
        findViewById<Button>(R.id.connect).setOnClickListener { connectCamera() }
        findViewById<Button>(R.id.start).setOnClickListener { startPass() }
        findViewById<Button>(R.id.end).setOnClickListener { finishPass("Manuell beendet") }
        findViewById<Button>(R.id.evaluate).setOnClickListener { reviewPass() }
        findViewById<Button>(R.id.calibrate).setOnClickListener { calibrate() }
        findViewById<Button>(R.id.finishTraining).setOnClickListener { finishTraining() }
        findViewById<TextView>(R.id.archive).text = db.archive()
        findViewById<Button>(R.id.end).visibility = View.GONE
        applyOrientationLayout(resources.configuration)
        refreshTraining()
    }

    /** Respect Android's status bar, navigation bar and tablet taskbar. */
    private fun installSystemBarInsets() {
        val root = findViewById<View>(R.id.appRoot)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            // The content and the bottom tab bar are inside the safe region.
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + .5f).toInt()

    /** Compact landscape dashboard; portrait keeps the reference proportions. */
    private fun applyOrientationLayout(config: Configuration) {
        val landscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE
        val header = findViewById<ViewGroup>(R.id.appRoot).getChildAt(0)
        header.layoutParams = header.layoutParams.apply { height = dp(if (landscape) 72 else 146) }
        val headerLogo = (header as? ViewGroup)?.getChildAt(0)
        headerLogo?.layoutParams = headerLogo?.layoutParams?.apply {
            width = dp(if (landscape) 55 else 112)
            height = dp(if (landscape) 62 else 125)
        }
        val nav = findViewById<RadioGroup>(R.id.tabs)
        nav.layoutParams = nav.layoutParams.apply { height = dp(if (landscape) 58 else 88) }
        val playerHost = findViewById<FrameLayout>(R.id.runVideoHost)
        playerHost.layoutParams = playerHost.layoutParams.apply { height = dp(if (landscape) 44 else 64) }
        dashboard.setCompactMode(landscape)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientationLayout(newConfig)
        ViewCompat.requestApplyInsets(findViewById(R.id.appRoot))
    }

    private fun showTargetDetails(index: Int) {
        val slot = monitor?.slots?.getOrNull(index)
        val message = if (slot == null) "Noch keine Passe gestartet." else buildString {
            appendLine("Pfeil vorhanden: ${if (slot.arrowPresent) "Ja (gespeichert)" else "Nein"}")
            appendLine("Veränderte Bildpunkte: ${slot.changedPixels}")
            appendLine("Kopfkandidaten: ${slot.headCandidates}")
            appendLine("Schaftpixel (Maske): ${slot.shaftPixels}")
            appendLine("Kopf-Kandidaten nach Filter: ${slot.acceptedHeads}")
            appendLine("Beste Schaftkontur: ${slot.bestPathLength} Pixel")
            appendLine("Ueberbrueckte Luecken: ${slot.bridgeCount}")
            appendLine("Plausible Einstichpunkte: ${slot.plausibleEndpoints}")
            appendLine("Schaftende-Projektion: %.1f px".format(slot.projectionPixels))
            appendLine("Lokaler Linienfehler: %.1f px".format(slot.projectionError))
            appendLine("Schaftanalyse: ${slot.diagnosis}")
            appendLine("Raumcluster: ${slot.clusterCount}")
            appendLine("Messungen im besten Cluster: ${slot.bestClusterVotes}/3")
            val hit = slot.hit ?: slot.candidate
            appendLine("Einstichpunkt: ${if (hit?.x == null || hit.y == null) "Unklar" else "x=${hit.x.toInt()}, y=${hit.y.toInt()}"}")
            appendLine("Wertungsvorschlag: ${slot.hit?.score?.toString() ?: "Offen"}")
            append("Sicherheit: ${slot.hit?.let { "${(it.confidence * 100).toInt()} %" } ?: "Nicht bestätigt"}")
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 12, 20, 8)
        }
        val snapshot = frame()
        if (snapshot != null && slot != null && index < calibration.size) {
            try {
                val ref = reference
                val aligned = if (ref != null) Vision.align(ref, snapshot).bitmap else snapshot
                try {
                    val c = calibration[index]
                    val sx = aligned.width.toFloat() / c.imageWidth.coerceAtLeast(1)
                    val sy = aligned.height.toFloat() / c.imageHeight.coerceAtLeast(1)
                    val x0 = ((c.cx - c.rx * 1.18f) * sx).toInt().coerceIn(0, aligned.width - 2)
                    val y0 = ((c.cy - c.ry * 1.18f) * sy).toInt().coerceIn(0, aligned.height - 2)
                    val x1 = ((c.cx + c.rx * 1.18f) * sx).toInt().coerceIn(x0 + 1, aligned.width)
                    val y1 = ((c.cy + c.ry * 1.18f) * sy).toInt().coerceIn(y0 + 1, aligned.height)
                    val crop = Bitmap.createBitmap(aligned, x0, y0, x1 - x0, y1 - y0)
                        .copy(Bitmap.Config.ARGB_8888, true)
                    val canvas = Canvas(crop)
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        strokeWidth = 3f
                        style = Paint.Style.STROKE
                    }
                    fun marker(x: Float, y: Float, colorValue: Int, radius: Float) {
                        paint.color = colorValue
                        canvas.drawCircle(x - x0, y - y0, radius, paint)
                    }
                    val points = slot.debugPath
                    paint.color = Color.CYAN
                    for (i in 1 until points.size) {
                        canvas.drawLine(points[i-1].first - x0, points[i-1].second - y0,
                            points[i].first - x0, points[i].second - y0, paint)
                    }
                    slot.debugHead?.let { marker(it.first, it.second, Color.GREEN, 7f) }
                    slot.debugAlternatives.forEach { marker(it.first, it.second, Color.YELLOW, 6f) }
                    val hit = slot.hit ?: slot.candidate
                    if (hit?.x != null && hit.y != null) marker(hit.x!!, hit.y!!, Color.RED, 10f)
                    column.addView(ImageView(this).apply {
                        setImageBitmap(crop)
                        adjustViewBounds = true
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        layoutParams = LinearLayout.LayoutParams(-1, 260)
                    })
                    column.addView(TextView(this).apply {
                        text = "Grün: Kopf   Blau: Schaftpfad   Rot: Wertung   Gelb: Alternativen"
                        textSize = 12f
                    })
                } finally {
                    if (aligned !== snapshot) aligned.recycle()
                }
            } catch (_: Exception) {
                column.addView(TextView(this).apply { text = "Bilddiagnose momentan nicht verfügbar" })
            } finally { snapshot.recycle() }
        }
        column.addView(TextView(this).apply { text = message; textSize = 13f; setPadding(0, 10, 0, 8) })
        val scroll = ScrollView(this).apply { addView(column) }
        AlertDialog.Builder(this)
            .setTitle("Scheibe ${index + 1} · Diagnose")
            .setView(scroll)
            .setPositiveButton("Schließen", null)
            .setNeutralButton("Wertung prüfen") { _, _ -> if (!running && monitor != null) reviewPass() }
            .show()
    }

    private fun moveCameraView(toRun: Boolean) {
        val view = findViewById<PlayerView>(R.id.playerView)
        val destination = findViewById<FrameLayout>(if (toRun) R.id.runVideoHost else R.id.cameraVideoHost)
        val other = findViewById<FrameLayout>(if (toRun) R.id.cameraVideoHost else R.id.runVideoHost)
        if (view.parent !== destination) {
            (view.parent as? ViewGroup)?.removeView(view)
            destination.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        destination.visibility = View.VISIBLE
        other.visibility = View.GONE
    }

    private fun createTraining() {
        if (running || monitor != null) { status.text = "Aktuelle Passe zuerst abschließen"; return }
        val name = findViewById<EditText>(R.id.name).text.toString().trim()
        val event = findViewById<EditText>(R.id.event).text.toString().trim()
        if (name.isEmpty() || event.isEmpty()) { status.text = "Teilnehmer und Training eingeben"; return }
        val goal = if (findViewById<Spinner>(R.id.passGoal).selectedItemPosition == 0) 5 else 10
        trainingId = db.create(name, event, goal)
        findViewById<TextView>(R.id.active).text = "$name · $event · $goal Passen"
        findViewById<TextView>(R.id.runParticipant).text = name
        findViewById<TextView>(R.id.runTrainingSubtitle).text = "$event · $goal Passen"
        refreshTraining()
    }

    private fun connectCamera() {
        try {
            stopLoop()
            if (::player.isInitialized) player.release()
            val ip = findViewById<EditText>(R.id.ip).text.toString().trim()
            val user = URLEncoder.encode(findViewById<EditText>(R.id.user).text.toString(), "UTF-8")
            val pass = URLEncoder.encode(findViewById<EditText>(R.id.pass).text.toString(), "UTF-8")
            if (ip.isBlank() || user.isBlank() || pass.isBlank()) { status.text = "Kameradaten eingeben"; return }
            player = ExoPlayer.Builder(this).build()
            findViewById<PlayerView>(R.id.playerView).player = player
            val media = MediaItem.fromUri("rtsp://$user:$pass@$ip:554/stream1")
            player.setMediaSource(RtspMediaSource.Factory().setForceUseRtpTcp(true).createMediaSource(media))
            player.addListener(object: Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        findViewById<TextView>(R.id.camStatus).text = "Tapo verbunden · ${player.videoSize.width}×${player.videoSize.height}"
                        findViewById<Button>(R.id.start).isEnabled = true
                        findViewById<Button>(R.id.calibrate).isEnabled = true
                    }
                }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    stopLoop()
                    findViewById<TextView>(R.id.camStatus).text = "Streamfehler: ${error.errorCodeName}"
                }
            })
            player.prepare()
            player.playWhenReady = true
        } catch (error: Exception) { status.text = "Verbindung: ${error.message}" }
    }

    private fun frame(): Bitmap? {
        if (!::player.isInitialized || player.playbackState != Player.STATE_READY) return null
        val texture = findViewById<PlayerView>(R.id.playerView).videoSurfaceView as? TextureView ?: return null
        if (!texture.isAvailable) return null
        val w = player.videoSize.width.takeIf { it > 0 } ?: texture.width
        val h = player.videoSize.height.takeIf { it > 0 } ?: texture.height
        if (w <= 0 || h <= 0) return null
        return try { texture.getBitmap(w, h) } catch (_: Exception) { null }
    }

    private fun calibrate() {
        if (running) { status.text = "Kalibrierung nur außerhalb einer Passe"; return }
        val image = frame() ?: run { status.text = "Kein Kamerabild"; return }
        status.text = "Kalibrierung läuft…"
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.Default) { Vision.calibrate(image) }
                if (result.size == 6) {
                    calibration = result
                    store.save(result)
                    findViewById<ImageView>(R.id.resultImage).setImageBitmap(Vision.renderOverlay(image, result, emptyList()))
                    status.text = "6 Scheiben kalibriert. Kreise überprüfen."
                } else status.text = "Kalibrierung: ${result.size}/6 Scheiben"
            } catch (error: Exception) { status.text = "Kalibrierungsfehler: ${error.message}" }
            finally { image.recycle() }
        }
    }

    private fun startPass() {
        if (running || reviewing || monitor != null) {
            status.text = "Vorherige Passe zuerst prüfen und speichern"
            return
        }
        val training = db.get(trainingId)
        if (training == null || training.completed || db.count(trainingId) >= training.goal) {
            status.text = "Aktives Training mit freien Passen anlegen"
            return
        }
        if (calibration.size != 6) { status.text = "Zuerst sechs Scheiben kalibrieren"; return }
        moveCameraView(toRun = true)
        val start = frame() ?: run {
            status.text = "Kein Referenzbild. Kamera-Tab öffnen und Livebild prüfen."
            return
        }
        reference?.recycle()
        reference = start
        monitor = LivePassMonitor(start, calibration)
        running = true
        dashboard.update(start, calibration, List(6) { null })
        findViewById<TextView>(R.id.liveSum).text = "0 / 60"
        findViewById<Button>(R.id.start).isEnabled = false
        findViewById<Button>(R.id.end).isEnabled = true
        findViewById<Button>(R.id.end).visibility = View.VISIBLE
        findViewById<Button>(R.id.start).visibility = View.GONE
        findViewById<Button>(R.id.evaluate).isEnabled = false
        findViewById<TextView>(R.id.liveStatus).text = (1..6).joinToString("\n") { "Scheibe $it: ⏳ Wartet" }
        status.text = "Passe gestartet. Live-Erkennung aktiv."
        findViewById<TextView>(R.id.liveHint).text = "Bitte schießen. Die App erkennt die Treffer automatisch."
        timer?.cancel()
        timer = object : CountDownTimer(180_000, 1000) {
            override fun onTick(ms: Long) {
                val seconds = (ms + 999) / 1000
                findViewById<TextView>(R.id.timer).text = "%02d:%02d".format(seconds / 60, seconds % 60)
            }
            override fun onFinish() {
                findViewById<TextView>(R.id.timer).text = "00:00"
                finishPass("Zeit abgelaufen")
            }
        }.start()
        loop = lifecycleScope.launch {
            while (running && isActive) {
                delay(750)
                val image = frame() ?: continue
                try {
                    val slots = withContext(Dispatchers.Default) { monitor?.accept(image) }
                    if (!running || slots == null) break
                    val sum = dashboard.update(image, calibration, slots,
                        monitor?.slots?.map { it.arrowPresent } ?: List(6) { false })
                    findViewById<TextView>(R.id.liveSum).text = "$sum / 60"
                    findViewById<TextView>(R.id.liveStatus).text = slots.mapIndexed { index, hit ->
                        if (hit == null && monitor?.slots?.getOrNull(index)?.arrowPresent == true)
                            "Scheibe ${index + 1}: Pfeil vorhanden, Wertung prüfen"
                        else if (hit == null) "Scheibe ${index + 1}: ⏳ Wartet"
                        else "Scheibe ${index + 1}: ✓ Erkannt · ${hit.score} Punkte · ${(hit.confidence * 100).toInt()} %"
                    }.joinToString("\n")
                    if (slots.all { it != null }) { finishPass("Alle 6 Pfeile erkannt"); break }
                } catch (error: Exception) { status.text = "Live-Analyse: ${error.message}" }
                finally { image.recycle() }
            }
        }
    }

    private fun finishPass(reason: String) {
        if (!running) return
        running = false
        timer?.cancel()
        loop?.cancel()
        findViewById<Button>(R.id.end).isEnabled = false
        findViewById<Button>(R.id.end).visibility = View.GONE
        findViewById<Button>(R.id.evaluate).isEnabled = true
        status.text = "$reason. Wertung prüfen und korrigieren."
        findViewById<TextView>(R.id.liveHint).text = "$reason. Bitte Wertungen kontrollieren."
        reviewPass()
    }

    private fun reviewPass() {
        if (running || reviewing) return
        val current = monitor ?: run { status.text = "Noch keine Passe gestartet"; return }
        reviewing = true
        val values = IntArray(6) { current.slots[it].hit?.score ?: -1 }
        val original = values.copyOf()
        val verified = BooleanArray(6) { false }
        val green = Color.rgb(25, 105, 65)
        val amber = Color.rgb(173, 105, 0)
        val red = Color.rgb(177, 43, 43)
        val muted = Color.rgb(89, 103, 98)
        val bg = Color.rgb(244, 247, 245)
        fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
        fun panel(color: Int, fill: Int = Color.WHITE) = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(2), color)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(container) }
        val total = TextView(this).apply {
            textSize = 23f
            setTypeface(null, Typeface.BOLD)
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(8))
        }
        val warning = TextView(this).apply {
            textSize = 14f
            setTextColor(red)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }
        container.addView(total)
        container.addView(warning)
        val cardViews = mutableListOf<Triple<LinearLayout, TextView, TextView>>()
        val scoreButtons = mutableListOf<List<Button>>()
        val choices = listOf(0, 6, 7, 8, 9, 10)
        fun update() {
            val counted = values.count { it >= 0 }
            val changed = values.indices.count { values[it] != original[it] }
            val needsReview = values.indices.count { !verified[it] }
            total.text = "${values.filter { it >= 0 }.sum()} Punkte  |  $counted/6 Scheiben"
            warning.text = when {
                needsReview > 0 -> "$needsReview Scheibe(n) noch prüfen · $changed Korrektur(en)"
                else -> "Alle sechs Wertungen kontrolliert · $changed Korrektur(en)"
            }
            cardViews.forEachIndexed { i, (card, state, subtitle) ->
                val hit = current.slots[i].hit
                val confidence = hit?.confidence ?: 0f
                val uncertain = hit == null || confidence < 0.55f
                val color = when {
                    verified[i] -> green
                    uncertain -> red
                    else -> amber
                }
                card.background = panel(color)
                state.setTextColor(color)
                state.text = when {
                    verified[i] && values[i] != original[i] -> "✓ Manuell korrigiert"
                    verified[i] -> "✓ Geprüft"
                    hit == null -> "● Nicht erkannt · Prüfung nötig"
                    uncertain -> "● Unsicher · Prüfung nötig"
                    else -> "● Prüfen · Vorschlag vorhanden"
                }
                subtitle.text = "Automatik: ${hit?.score?.toString() ?: "Wartet"}   |   Sicherheit: ${if (hit == null) "–" else "${(confidence * 100).toInt()} %"}   |   Endwert: ${if (values[i] < 0) "offen" else values[i].toString()}"
                scoreButtons[i].forEachIndexed { index, button ->
                    val selected = values[i] == choices[index]
                    button.isAllCaps = false
                    button.setTextColor(if (selected) Color.WHITE else green)
                    button.backgroundTintList = android.content.res.ColorStateList.valueOf(if (selected) green else Color.rgb(231, 238, 233))
                }
            }
        }
        repeat(6) { index ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }
            }
            val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val title = TextView(this).apply {
                text = "Scheibe ${index + 1}"
                textSize = 19f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.rgb(20, 65, 43))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val state = TextView(this).apply { textSize = 13f; setTypeface(null, Typeface.BOLD) }
            heading.addView(title)
            heading.addView(state)
            card.addView(heading)
            val subtitle = TextView(this).apply {
                textSize = 13f
                setTextColor(muted)
                setPadding(0, dp(8), 0, dp(8))
            }
            card.addView(subtitle)
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val rowButtons = choices.map { score ->
                Button(this).apply {
                    text = score.toString()
                    textSize = 14f
                    minWidth = 0
                    minimumWidth = 0
                    minHeight = dp(44)
                    minimumHeight = dp(44)
                    setPadding(0, 0, 0, 0)
                    layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(3) }
                    setOnClickListener { values[index] = score; verified[index] = true; update() }
                }.also(buttons::addView)
            }
            card.addView(buttons)
            val confirm = Button(this).apply {
                text = "Wertung bestätigen"
                isAllCaps = false
                setOnClickListener {
                    if (values[index] < 0) {
                        Toast.makeText(this@MainActivity, "Bitte zuerst eine Punktzahl wählen", Toast.LENGTH_SHORT).show()
                    } else {
                        verified[index] = true
                        update()
                    }
                }
            }
            card.addView(confirm)
            container.addView(card)
            cardViews.add(Triple(card, state, subtitle))
            scoreButtons.add(rowButtons)
        }
        update()
        val nextPassNumber = if (trainingId > 0) db.count(trainingId) + 1 else 1
        val dialog = AlertDialog.Builder(this)
            .setTitle("Wertungskontrolle · Passe $nextPassNumber")
            .setView(scroll)
            .setPositiveButton("Geprüfte Passe speichern", null)
            .setNegativeButton("Später korrigieren") { _, _ -> reviewing = false }
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (values.any { it < 0 } || verified.any { !it }) {
                    Toast.makeText(this, "Alle sechs Scheiben bewerten und bestätigen", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (trainingId <= 0) { status.text = "Kein Training"; return@setOnClickListener }
                val saved = db.addPass(trainingId, values.sum(), values.joinToString(","))
                if (saved) {
                    status.text = "Passe geprüft und gespeichert: ${values.sum()} Punkte"
                    reviewing = false
                    monitor = null
                    reference?.recycle()
                    reference = null
                    findViewById<Button>(R.id.evaluate).isEnabled = false
                    findViewById<Button>(R.id.start).isEnabled = true
                    findViewById<Button>(R.id.start).visibility = View.VISIBLE
                    findViewById<TextView>(R.id.timer).text = "03:00"
                    refreshTraining()
                    dialog.dismiss()
                } else status.text = "Speichern fehlgeschlagen"
            }
        }
        dialog.setOnDismissListener { reviewing = false }
        dialog.show()
    }

    private fun finishTraining() {
        val training = db.get(trainingId)
        if (training == null || db.count(trainingId) < training.goal) {
            status.text = "Training noch nicht vollständig"
            return
        }
        db.finish(trainingId)
        refreshTraining()
        findViewById<RadioButton>(R.id.t5).isChecked = true
    }

    private fun refreshTraining() {
        val training = db.get(trainingId)
        if (training != null) {
            val count = db.count(trainingId)
            findViewById<TextView>(R.id.passProgress).text = "Passe ${count + if (training.completed) 0 else 1}/${training.goal}"
            findViewById<TextView>(R.id.runParticipant).text = training.participant
            findViewById<TextView>(R.id.runTrainingSubtitle).text = "${training.name} · ${training.goal} Passen"
            findViewById<Button>(R.id.finishTraining).isEnabled = !training.completed && count >= training.goal
            findViewById<TextView>(R.id.history).text = db.currentPasses(trainingId)
        }
        findViewById<TextView>(R.id.archive).text = db.archive()
    }

    private fun stopLoop() {
        running = false
        timer?.cancel()
        loop?.cancel()
    }

    override fun onDestroy() {
        stopLoop()
        if (::player.isInitialized) player.release()
        reference?.recycle()
        db.close()
        super.onDestroy()
    }
}
