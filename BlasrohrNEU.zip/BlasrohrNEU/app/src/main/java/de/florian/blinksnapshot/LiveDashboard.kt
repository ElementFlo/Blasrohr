package de.florian.blinksnapshot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

/** Real camera crops, never synthetic target drawings. */
class LiveDashboard(private val context: Context, private val grid: GridLayout) {
    private data class Tile(val image: ImageView, val state: TextView, val score: TextView, val confidence: TextView)
    private val tiles = mutableListOf<Tile>()
    fun setCompactMode(compact: Boolean) {
        val height = dp(if (compact) 112 else 205)
        tiles.forEach { tile ->
            tile.image.layoutParams = tile.image.layoutParams.apply { this.height = height }
            tile.image.requestLayout()
        }
    }
    private val darkGreen = Color.rgb(0, 71, 45)
    var onDetails: ((Int) -> Unit)? = null
    private fun dp(n: Int) = (n * context.resources.displayMetrics.density + .5f).toInt()
    private fun rounded(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(12).toFloat() }

    init {
        val columns = 3
        grid.columnCount = columns
        repeat(6) { index ->
            val card = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Color.WHITE)
                elevation = dp(2).toFloat()
                setPadding(dp(1), dp(1), dp(1), dp(3))
            }
            val titleBar = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = rounded(darkGreen)
            }
            titleBar.addView(TextView(context).apply {
                text = "Scheibe ${index + 1}"
                textSize = 16f
                setTextColor(Color.WHITE)
                setTypeface(null, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            val state = TextView(context).apply { text = "⏳ Wartet"; textSize = 12f; setTextColor(Color.WHITE) }
            titleBar.addView(state)
            card.addView(titleBar)
            val image = ImageView(context).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.rgb(225, 232, 227))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(205))
                contentDescription = "Liveausschnitt Scheibe ${index + 1}"
            }
            card.addView(image)
            val info = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5), dp(7), dp(5), dp(7)) }
            val scoreColumn = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            scoreColumn.addView(TextView(context).apply { text = "Wertung"; textSize = 11f; setTextColor(Color.BLACK) })
            val score = TextView(context).apply { text = "–"; textSize = 25f; setTypeface(null, Typeface.BOLD); setTextColor(darkGreen) }
            scoreColumn.addView(score)
            val confidenceColumn = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
            confidenceColumn.addView(TextView(context).apply { text = "Sicherheit"; textSize = 11f; setTextColor(Color.BLACK) })
            val confidence = TextView(context).apply { text = "– %"; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(Color.DKGRAY) }
            confidenceColumn.addView(confidence)
            val details = Button(context).apply { text = "DETAILS"; textSize = 10f; isAllCaps = false; minWidth = 0; minimumWidth = 0; setPadding(0,0,0,0); layoutParams = LinearLayout.LayoutParams(0, dp(48), 1.15f); setOnClickListener { onDetails?.invoke(index) } }
            info.addView(scoreColumn); info.addView(confidenceColumn); info.addView(details)
            card.addView(info)
            val lp = GridLayout.LayoutParams(GridLayout.spec(index / columns), GridLayout.spec(index % columns)).apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(index % columns, 1, 1f)
                setMargins(dp(3), dp(4), dp(3), dp(4))
            }
            grid.addView(card, lp)
            tiles.add(Tile(image, state, score, confidence))
        }
    }

    fun update(frame: Bitmap?, calibration: List<TargetCal>, hits: List<Hit?>,
               present: List<Boolean> = List(6) { false }): Int {
        var sum = 0
        tiles.forEachIndexed { i, tile ->
            val hit = hits.getOrNull(i)
            val color = when {
                hit == null -> Color.rgb(90, 100, 98)
                hit.confidence < .55f -> Color.rgb(175, 48, 40)
                hit.confidence < .80f -> Color.rgb(169, 110, 0)
                else -> Color.rgb(20, 116, 65)
            }
            tile.state.text = when {
                hit == null && present.getOrElse(i) { false } -> "! Pfeil · prüfen"
                hit == null -> "⏳ Wartet"
                hit.confidence < .55f -> "! Unsicher"
                else -> "✓ Erkannt"
            }
            tile.state.setTextColor(if (hit == null && present.getOrElse(i) { false }) Color.YELLOW
                else if (hit == null) Color.WHITE else Color.rgb(245, 222, 132))
            tile.score.text = hit?.score?.toString() ?: "–"
            tile.score.setTextColor(color)
            tile.confidence.text = hit?.let { "${(it.confidence * 100).toInt()} %" } ?: "– %"
            if (hit != null) sum += hit.score
            if (frame != null && i < calibration.size) {
                val c = calibration[i]
                val sx = frame.width.toFloat() / c.imageWidth.coerceAtLeast(1)
                val sy = frame.height.toFloat() / c.imageHeight.coerceAtLeast(1)
                val x0 = ((c.cx - c.rx * 1.12f) * sx).toInt().coerceIn(0, frame.width - 1)
                val y0 = ((c.cy - c.ry * 1.12f) * sy).toInt().coerceIn(0, frame.height - 1)
                val x1 = ((c.cx + c.rx * 1.12f) * sx).toInt().coerceIn(x0 + 1, frame.width)
                val y1 = ((c.cy + c.ry * 1.12f) * sy).toInt().coerceIn(y0 + 1, frame.height)
                val crop = Bitmap.createBitmap(frame, x0, y0, x1 - x0, y1 - y0)
                if (hit?.x != null && hit.y != null) {
                    val overlay = crop.copy(Bitmap.Config.ARGB_8888, true)
                    val canvas = Canvas(overlay)
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        this.color = if (hit.confidence < .55f) Color.RED else Color.GREEN
                        style = Paint.Style.STROKE
                        strokeWidth = 3f
                    }
                    val px = hit.x - x0
                    val py = hit.y - y0
                    canvas.drawCircle(px, py, 11f, paint)
                    canvas.drawLine(px - 17f, py, px + 17f, py, paint)
                    canvas.drawLine(px, py - 17f, px, py + 17f, paint)
                    tile.image.setImageBitmap(overlay)
                    crop.recycle()
                } else tile.image.setImageBitmap(crop)
            }
        }
        return sum
    }
}
