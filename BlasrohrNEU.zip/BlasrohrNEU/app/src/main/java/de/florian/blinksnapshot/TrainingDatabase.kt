package de.florian.blinksnapshot
import android.content.*
import android.database.sqlite.*
import java.text.SimpleDateFormat
import java.util.*
data class Training(val id:Long,val participant:String,val name:String,val goal:Int,val completed:Boolean,val created:Long,val completedAt:Long?)
class TrainingDatabase(c:Context):SQLiteOpenHelper(c,"kks_training_v1.db",null,1){
 override fun onCreate(d:SQLiteDatabase){d.execSQL("CREATE TABLE training(id INTEGER PRIMARY KEY AUTOINCREMENT,participant TEXT NOT NULL,name TEXT NOT NULL,goal INTEGER NOT NULL,completed INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL,completed_at INTEGER)");d.execSQL("CREATE TABLE pass(id INTEGER PRIMARY KEY AUTOINCREMENT,training_id INTEGER NOT NULL,number INTEGER NOT NULL,total INTEGER NOT NULL,scores TEXT NOT NULL,created INTEGER NOT NULL,UNIQUE(training_id,number))")}
 override fun onUpgrade(d:SQLiteDatabase,o:Int,n:Int){}
 fun create(p:String,n:String,g:Int):Long=writableDatabase.insert("training",null,ContentValues().apply{put("participant",p);put("name",n);put("goal",g);put("created",System.currentTimeMillis())})
 fun get(id:Long):Training?=readableDatabase.rawQuery("SELECT id,participant,name,goal,completed,created,completed_at FROM training WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())Training(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getInt(4)==1,c.getLong(5),if(c.isNull(6))null else c.getLong(6))else null}
 fun count(id:Long)=readableDatabase.rawQuery("SELECT COUNT(*) FROM pass WHERE training_id=?",arrayOf(id.toString())).use{it.moveToFirst();it.getInt(0)}
 fun addPass(id:Long,total:Int,scores:String):Boolean{val n=count(id)+1;return writableDatabase.insertWithOnConflict("pass",null,ContentValues().apply{put("training_id",id);put("number",n);put("total",total);put("scores",scores);put("created",System.currentTimeMillis())},SQLiteDatabase.CONFLICT_IGNORE)>0}
 fun finish(id:Long)=writableDatabase.update("training",ContentValues().apply{put("completed",1);put("completed_at",System.currentTimeMillis())},"id=?",arrayOf(id.toString()))
 fun currentPasses(id:Long):String=readableDatabase.rawQuery("SELECT number,total,scores FROM pass WHERE training_id=? ORDER BY number",arrayOf(id.toString())).use{c->val a=mutableListOf<String>();while(c.moveToNext())a.add("Passe ${c.getInt(0)}: ${c.getInt(1)} Punkte  [${c.getString(2)}]");if(a.isEmpty())"Noch keine Passen" else a.joinToString("\n\n")}
 fun archive():String=readableDatabase.rawQuery("SELECT id,participant,name,goal,completed_at FROM training WHERE completed=1 ORDER BY completed_at DESC",null).use{c->val a=mutableListOf<String>();val f=SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.GERMANY);while(c.moveToNext()){val id=c.getLong(0);val sum=readableDatabase.rawQuery("SELECT COUNT(*),COALESCE(SUM(total),0) FROM pass WHERE training_id=?",arrayOf(id.toString())).use{s->s.moveToFirst();Pair(s.getInt(0),s.getInt(1))};a.add("${c.getString(1)} · ${c.getString(2)}\nBeendet: ${f.format(Date(c.getLong(4)))}\n${sum.first}/${c.getInt(3)} Passen · ${sum.second} Punkte")};if(a.isEmpty())"Noch keine vollständig beendeten Trainingsdurchläufe" else a.joinToString("\n\n────────────────\n\n")}
}
