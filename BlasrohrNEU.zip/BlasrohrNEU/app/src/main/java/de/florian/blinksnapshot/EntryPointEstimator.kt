package de.florian.blinksnapshot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Determines the likely paper-entry end of a detected metal shaft.
 * The colored plastic head can be any hue: we use a newly appearing,
 * compact, saturated blob near one shaft end, not a specific RGB color.
 * If the two ends cannot be distinguished, do not invent an entry point.
 */
object EntryPointEstimator {
    data class Estimate(val x: Float, val y: Float, val confidence: Float)

    fun fromEndpoints(
        before: Bitmap,
        after: Bitmap,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        targetRadius: Float
    ): Estimate? {
        val searchRadius = (targetRadius * 0.16f).toInt().coerceIn(6, 25)
        val head1 = headEvidence(before, after, x1, y1, searchRadius)
        val head2 = headEvidence(before, after, x2, y2, searchRadius)
        val strongest = maxOf(head1, head2)
        val weakest = minOf(head1, head2)
        if (strongest < 6 || strongest < weakest * 1.8f + 4f) return null
        // The plastic head is at the endpoint with more colored-blob evidence.
        // The opposite shaft endpoint is the proposed entry point.
        return if (head1 > head2) Estimate(x2, y2, (0.35f + (head1-head2).toFloat()/strongest * 0.4f).coerceAtMost(0.75f))
        else Estimate(x1, y1, (0.35f + (head2-head1).toFloat()/strongest * 0.4f).coerceAtMost(0.75f))
    }

    private fun headEvidence(before: Bitmap, after: Bitmap, cx: Float, cy: Float, radius: Int): Int {
        var evidence = 0
        val x0 = (cx.toInt()-radius).coerceAtLeast(0)
        val x1 = (cx.toInt()+radius).coerceAtMost(minOf(before.width,after.width)-1)
        val y0 = (cy.toInt()-radius).coerceAtLeast(0)
        val y1 = (cy.toInt()+radius).coerceAtMost(minOf(before.height,after.height)-1)
        for (y in y0..y1 step 2) for (x in x0..x1 step 2) {
            if (hypot(x-cx,y-cy) > radius) continue
            val a = after.getPixel(x,y)
            val b = before.getPixel(x,y)
            val max = maxOf(Color.red(a),Color.green(a),Color.blue(a))
            val min = minOf(Color.red(a),Color.green(a),Color.blue(a))
            val change = abs(Color.red(a)-Color.red(b)) + abs(Color.green(a)-Color.green(b)) + abs(Color.blue(a)-Color.blue(b))
            if (max-min > 55 && change > 65) evidence++
        }
        return evidence
    }
}
