package de.florian.blinksnapshot

import android.content.Context

class CalStore(context: Context) {
    private val preferences = context.getSharedPreferences("calibration", 0)

    fun save(values: List<TargetCal>) {
        preferences.edit().putString("v3", values.joinToString(";") { target ->
            listOf(target.cx, target.cy, target.rx, target.ry)
                .plus(target.rings)
                .plus(listOf(target.imageWidth.toFloat(), target.imageHeight.toFloat()))
                .joinToString(",")
        }).apply()
    }

    fun load(): List<TargetCal> {
        return preferences.getString("v3", null)?.split(";")?.mapNotNull { entry ->
            val value = entry.split(",").mapNotNull { it.toFloatOrNull() }
            if (value.size >= 10) TargetCal(value[0], value[1], value[2], value[3], value.subList(4, 8), value[8].toInt(), value[9].toInt()) else null
        } ?: emptyList()
    }
}
