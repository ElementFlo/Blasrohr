package de.florian.blinksnapshot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot

/** Stage one: detects a persistent local image change, NOT a scored entry point.
 * Sampled pixels avoid the preprinted ring edges by comparing against the reference.
 */
object ArrowPresenceDetector {
    data class Evidence(val present: Boolean, val changedPixels: Int, val fraction: Float)

    fun detect(before: Bitmap, after: Bitmap, target: TargetCal): Evidence {
        val w = minOf(before.width, after.width)
        val h = minOf(before.height, after.height)
        val left = (target.cx - target.rx * .92f).toInt().coerceIn(0, w - 1)
        val right = (target.cx + target.rx * .92f).toInt().coerceIn(left, w - 1)
        val top = (target.cy - target.ry * .92f).toInt().coerceIn(0, h - 1)
        val bottom = (target.cy + target.ry * .92f).toInt().coerceIn(top, h - 1)
        var changed = 0
        var total = 0
        var maxTile = 0
        val tile = 7
        for (y0 in top..bottom step tile) for (x0 in left..right step tile) {
            var local = 0
            for (y in y0..minOf(y0 + tile - 1, bottom) step 2)
                for (x in x0..minOf(x0 + tile - 1, right) step 2) {
                    if (hypot((x - target.cx) / target.rx, (y - target.cy) / target.ry) > .92f) continue
                    total++
                    val a = before.getPixel(x, y)
                    val b = after.getPixel(x, y)
                    val change = abs(Color.red(a) - Color.red(b)) +
                        abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))
                    if (change >= 48) { changed++; local++ }
                }
            maxTile = maxOf(maxTile, local)
        }
        val fraction = if (total == 0) 0f else changed.toFloat() / total
        // Broad illumination changes are not reliable evidence of an arrow.
        val present = changed >= 5 && maxTile >= 2 && fraction in .001f..0.13f
        return Evidence(present, changed, fraction)
    }
}
